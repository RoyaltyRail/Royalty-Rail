# Royalty Rail writer page

- [x] Responsive single-page writer statement with prominent TESTNET ONLY messaging and no mainnet or real-funds path. Use generic names only, such as UK society (demo), and no real society names or logos.
- [x] Writer address entry with writer-a and writer-b presets populated from deployment.json.
- [x] Discover statements from PayeeSettled events using the indexed payee topic; fall back to statement IDs in deployment.json. Empty bounded RPC ledger scans paginate through to the latest ledger.
- [x] Show territory, source, period, amount, and Paid / Held / Credited per line. Held lines show reason code, note, and live countdown to expiry. Distinguish current payout state from immutable settlement receipts.
- [x] Verify each line using verify_receipt and display ✓ or ✗. A tamper toggle changes exactly one hash character to visibly fail verification, and the displayed hash is exactly the hash submitted.
- [x] Holds panel: Release my money enabled only at expiry, calls claim_expired signed with Freighter or the demo writer-b testnet key. Demo key input remains in memory only; no private key in published assets. SDK claim hold 2 confirmed SUCCESS and paid exactly 350 EURD; early claim hold 3 rejected. Only confirmed SUCCESS is presented as paid.
- [x] @stellar/stellar-sdk calls the pinned testnet RPC. Existing Soroban contract logic remains unchanged. TypeScript and production build pass. Read-only implementation review completed; identified issues corrected.
- [x] Confirm public deployment and deliver the updated source repository zip. Published at https://royaltyrail-jcebongp.manus.space; source and validation evidence included in this archive.
