import { Buffer } from "buffer";
import "./fonts.css";
import "./style.css";
import {
  loadDeployment,
  RailClient,
  connectFreighter,
  type Deployment,
  type Receipt,
  type Hold,
  type WriterData,
} from "./rail";

(globalThis as unknown as { Buffer: typeof Buffer }).Buffer = Buffer;
const app = document.querySelector<HTMLDivElement>("#app")!;
let deployment: Deployment;
let client: RailClient;
let data: WriterData | null = null;
let writer = "";
let loading = false;
let error = "";
let notice = "";
let claimBusy = false;
let wallet = "";
let signing: "demo" | "freighter" = "demo";
let demoSecret = ""; // Memory only. Never bundled, logged, persisted, or sent to an application server.
let lastSync = "";
let clockOffset = 0;
let chainTime = 0;
let filter = "all";
let loadVersion = 0;
let showSigner = false;
const verification = new Map<
  string,
  { tamper: boolean; result?: boolean; busy?: boolean; error?: string }
>();

const esc = (v: unknown) =>
  String(v ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ]!,
  );
const short = (s: string) => `${s.slice(0, 6)}…${s.slice(-6)}`;
const key = (r: Receipt) => `${r.statement_id}:${r.line_index}:${r.payee}`;
const now = () => Math.floor(Date.now() / 1000 + clockOffset);
const money = (units: bigint) => {
  const negative = units < 0n;
  const n = negative ? -units : units;
  const whole = (n / 10000000n).toLocaleString("en-US");
  const fraction = (n % 10000000n)
    .toString()
    .padStart(7, "0")
    .replace(/0+$/, "")
    .padEnd(2, "0");
  return `${negative ? "-" : ""}${whole}.${fraction}`;
};
const territory: Record<string, string> = {
  PT: "Portugal",
  GB: "United Kingdom",
  NG: "Nigeria",
};
const source: Record<string, string> = {
  LIVE: "Live performance",
  RADIO: "Radio",
  STREAM: "Streaming",
  TV: "Television",
};
function state(r: Receipt): "Paid" | "Held" | "Credited" {
  if (
    r.status.kind === "Held" &&
    data?.holds.find((h) => h.id === r.status.holdId)?.open === false
  )
    return "Paid";
  return r.status.kind;
}
const countdown = (expiry: number) => {
  const secs = Math.max(0, expiry - now());
  return secs
    ? `${Math.floor(secs / 60)
        .toString()
        .padStart(2, "0")}:${(secs % 60).toString().padStart(2, "0")}`
    : "Expired";
};
function icon(name: string) {
  const paths: Record<string, string> = {
    arrow: '<path d="M4 12h16m-6-6 6 6-6 6"/>',
    refresh:
      '<path d="M20 7v5h-5M4 17v-5h5"/><path d="M6 7a7 7 0 0 1 12-2l2 7M4 12l2 7a7 7 0 0 0 12-2"/>',
    shield:
      '<path d="M12 3 4 6v6c0 5 8 9 8 9s8-4 8-9V6l-8-3Z"/><path d="m8 12 3 3 5-6"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    wallet:
      '<rect x="3" y="5" width="18" height="15" rx="3"/><path d="M3 9h18m-5 5h3"/>',
    link: '<path d="M14 3h7v7m0-7L10 14M10 3H4v17h17v-6"/>',
    copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V4H4v12h4"/>',
  };
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.arrow}</svg>`;
}

function render() {
  const receipts = data?.receipts ?? [];
  const total = receipts.reduce((a, r) => a + r.amount, 0n);
  const sum = (status: string) =>
    receipts
      .filter((r) => state(r) === status)
      .reduce((a, r) => a + r.amount, 0n);
  const held = sum("Held");
  const activeHolds = data?.holds.filter((h) => h.open) ?? [];
  const closed = data?.holds.filter((h) => !h.open) ?? [];
  const visible =
    filter === "all"
      ? receipts
      : receipts.filter((r) => state(r).toLowerCase() === filter);
  const groups = [...new Set(visible.map((r) => r.statement_id))];
  const writerName =
    deployment && writer === deployment.accounts["writer-a"]
      ? "Writer A"
      : deployment && writer === deployment.accounts["writer-b"]
        ? "Writer B"
        : "Writer";
  app.innerHTML = `
    <header class="topbar"><a class="wordmark" href="/" aria-label="Royalty Rail home"><img src="/mark.svg" alt=""/>royalty<span>rail</span></a><nav><a href="#statements" class="nav-current">Writer statement</a><a href="#how">How it works</a></nav><span class="testnet-badge"><span class="pulse-dot"></span>TESTNET ONLY</span></header>
    <main>
      <section class="hero"><div><div class="eyebrow"><span class="tiny-line"></span> THE WRITER'S SIDE OF THE STORY</div><h1>Your royalties.<br/><span>With receipts.</span></h1><p>See where your money went. Prove every payment.<br class="desktop"/> And when a hold expires, release it yourself.</p></div><div class="hero-note"><span class="note-num">01 — 03</span><div>Agreed splits.<br/>Visible holds.<br/><strong>No indefinite waiting.</strong></div><span class="note-bottom">ON STELLAR · DEMO ASSETS ONLY</span></div></section>
      <section class="address-panel" aria-label="Select writer"><div class="address-intro"><span class="field-label">YOUR WRITER ADDRESS</span><div class="presets"><button data-writer="writer-a" class="preset ${writer === deployment?.accounts["writer-a"] ? "selected" : ""}">Writer A <span>40%</span></button><button data-writer="writer-b" class="preset ${writer === deployment?.accounts["writer-b"] ? "selected" : ""}">Writer B <span>35%</span></button></div></div><form id="address-form"><label class="sr-only" for="writer-address">Stellar writer address</label><input id="writer-address" name="address" placeholder="Paste a Stellar address, G…" value="${esc(writer)}" spellcheck="false" autocomplete="off" required/><button class="primary" type="submit" ${loading ? "disabled" : ""}>${loading ? "Reading chain…" : "View statement"}${icon("arrow")}</button></form><span class="address-hint">Public address only. Reading your statement needs no wallet connection.</span></section>
      ${error ? `<div class="alert error" role="alert">${esc(error)} <button id="retry">Try again</button></div>` : ""}
      ${notice ? `<div class="alert success" role="status">${esc(notice)}</div>` : ""}
      <section class="statement-header" id="statements"><div><span class="eyebrow">${esc(writerName.toUpperCase())} / ROYALTY OVERVIEW</span><h2>Your writer statement <span class="count-pill">${receipts.length} lines</span></h2></div><button id="refresh" class="text-button" ${loading ? "disabled" : ""}>${icon("refresh")} Refresh</button></section>
      <section class="totals" aria-label="Payment totals"><div class="total total-main"><span class="field-label">TOTAL ROYALTIES</span><div>${loading && !data ? "—" : money(total)}<span> EURD</span></div><small>${data?.statementIds.length ?? 0} statements · UK society (demo)</small></div><div class="total"><span class="field-label"><i class="status-dot green"></i> PAID TO YOU</span><div>${money(sum("Paid"))}<span> EURD</span></div><small>Delivered, including released holds</small></div><div class="total"><span class="field-label"><i class="status-dot amber"></i> IN ESCROW</span><div>${money(held)}<span> EURD</span></div><small>Held transparently, never silently</small></div><div class="total"><span class="field-label"><i class="status-dot blue"></i> CREDITED</span><div>${money(sum("Credited"))}<span> EURD</span></div><small>Undelivered at settlement</small></div></section>
      <div class="content-layout"><section class="statement-list" aria-label="Royalty statements"><div class="list-toolbar"><div class="filters" role="group" aria-label="Filter payment status">${["all", "paid", "held", "credited"].map((f) => `<button data-filter="${f}" class="${filter === f ? "active" : ""}">${f === "all" ? "All lines" : f[0].toUpperCase() + f.slice(1)}</button>`).join("")}</div><span class="onchain-label"><span class="pulse-dot"></span> Live on-chain</span></div>
      ${
        loading && !data
          ? '<div class="loading-block"><span class="spinner"></span> Reading receipts from Stellar testnet…</div>'
          : !visible.length
            ? `<div class="empty">${data ? "No statement lines found for this address or filter." : "Enter a writer address to read their statement."}<small>Demo presets above are ready to explore.</small></div>`
            : groups
                .map(
                  (id) =>
                    `<article class="statement"><div class="statement-title"><div><span class="field-label">UK SOCIETY (DEMO)</span><h3>${id.includes("STAGE") ? "Live stage statement" : id.includes("Q3") ? "Third quarter · 2027" : id.includes("Q4") ? "Fourth quarter · 2027" : "Royalty statement"}</h3><span class="mono statement-id">${esc(id)}</span></div><span class="statement-total">${money(visible.filter((r) => r.statement_id === id).reduce((s, r) => s + r.amount, 0n))}<small>EURD · your share</small></span></div>${visible
                      .filter((r) => r.statement_id === id)
                      .map(receiptHtml)
                      .join("")}</article>`,
                )
                .join("")
      }
      <div class="chain-footer">${icon("shield")}<span>${data ? `Ledger ${data.ledger.toLocaleString()} · ${data.discovery === "events" ? "Discovered from your indexed settlement events" : data.discovery === "mixed" ? "Indexed events + deployment fallback" : "Deployment fallback; receipts read live from RPC"}${lastSync ? ` · synced ${esc(lastSync)}` : ""}` : "Receipts are read directly from the contract, not a private database."}</span></div>
      ${data?.warnings.length ? `<details class="diagnostics"><summary>RPC notices (${data.warnings.length})</summary>${data.warnings.map((w) => `<p>${esc(w)}</p>`).join("")}</details>` : ""}
      </section><aside class="holds-panel"><div class="holds-heading">${icon("clock")}<h2>Your holds</h2><span class="count-pill">${activeHolds.length}</span></div><p class="panel-description">A hold needs a reason and an expiry.<br/>The society cannot keep you waiting forever.</p>
      ${activeHolds.length ? activeHolds.map(holdHtml).join("") : '<div class="no-holds">' + icon("shield") + "<strong>No open holds</strong><span>Your money is not in escrow.</span></div>"}
      <div class="signer"><button id="signer-toggle" class="signer-toggle">${icon("wallet")} Release signing <span>${signing === "demo" ? "Demo testnet key" : "Freighter"} ${showSigner ? "−" : "+"}</span></button>${showSigner ? `<div class="signer-options"><label for="signer-mode">Transaction signer</label><select id="signer-mode"><option value="demo" ${signing === "demo" ? "selected" : ""}>Demo writer-b testnet key</option><option value="freighter" ${signing === "freighter" ? "selected" : ""}>Freighter wallet (testnet)</option></select>${signing === "demo" ? '<label for="demo-key">Demo writer-b secret key</label><input id="demo-key" type="password" placeholder="S… from demo/demo-keys.json" autocomplete="off" spellcheck="false"/><small>Use only the generated demo testnet key. Kept in memory; never saved or sent to this site’s server.</small>' : `<button id="connect" class="secondary">${wallet ? esc(short(wallet)) : "Connect Freighter"}</button><small>Freighter must be set to testnet. You sign a test-XLM transaction fee; no society signature is needed.</small>`}</div>` : ""}</div>
      <div class="holds-footnote">${icon("shield")}<p><strong>No society signature.</strong> After expiry, anyone can trigger release. The contract sends escrow only to the writer named on the hold.</p></div>
      ${closed.length ? `<details class="hold-history"><summary>${closed.length} released hold${closed.length > 1 ? "s" : ""}</summary>${closed.map((h) => `<div><span>Hold #${esc(h.id)} · ${esc(h.reason)}</span><strong>Paid to writer</strong></div>`).join("")}</details>` : ""}
      </aside></div>
      <section class="how" id="how"><div><span class="eyebrow">BUILT FOR WRITERS, NOT BLIND TRUST</span><h2>A statement you can stand behind.</h2></div><div class="how-facts"><div><span>01</span><strong>Check the facts</strong><p>Every line has its own on-chain receipt. Verify the hash without connecting a wallet.</p></div><div><span>02</span><strong>See the hold</strong><p>A reason, a note, an expiry. Your share sits visibly in escrow while everyone else is paid.</p></div><div><span>03</span><strong>Release your money</strong><p>When the clock runs out, release the escrow yourself. No society approval required.</p></div></div></section>
      <footer><span>royalty rail <span class="footer-dot">/</span> HackMeridian demo</span><div><a href="https://stellar.expert/explorer/testnet/contract/${esc(deployment?.contract_id ?? "")}" target="_blank" rel="noopener noreferrer">View contract ${icon("link")}</a><span>EURD is a demo token. No real funds.</span></div></footer>
    </main>`;
  bind();
  tick();
}

function receiptHtml(r: Receipt) {
  const v = verification.get(key(r)) ?? { tamper: false };
  const s = state(r);
  const hold = r.status.holdId
    ? data?.holds.find((h) => h.id === r.status.holdId)
    : undefined;
  const fullHash = v.tamper
    ? `${r.hash[0] === "0" ? "1" : "0"}${r.hash.slice(1)}`
    : r.hash;
  return `<div class="receipt ${s.toLowerCase()}" data-receipt="${esc(key(r))}"><div class="receipt-top"><div class="territory-stamp">${esc(r.territory)}</div><div class="line-description"><h4>${esc(source[r.source] ?? r.source)}</h4><span>${esc(territory[r.territory] ?? r.territory)} <i>·</i> ${esc(r.period)} <i>·</i> Line ${r.line_index + 1}</span></div><div class="line-payment"><strong>${money(r.amount)} <small>EURD</small></strong><span class="status ${s.toLowerCase()}">${s === "Paid" ? "✓" : s === "Held" ? "◷" : "↳"} ${s}</span></div></div>
    ${r.status.kind === "Held" ? `<div class="held-detail">${hold && !hold.open ? `<span>Released from hold #${esc(hold.id)}. The original receipt remains Held and verifiable.</span>` : `<span><strong>${esc(hold?.reason ?? "HELD")}</strong> ${hold ? esc(hold.note) : "Hold detail unavailable; refresh to retry."}</span>${hold ? `<div>${icon("clock")}<span class="countdown" data-expiry="${hold.expires_at}">${countdown(hold.expires_at)}</span><small>to expiry</small></div>` : ""}`}</div>` : r.status.kind === "Credited" ? '<div class="credit-detail">Delivery failed at settlement. This receipt records a credit, not a bank payment. Use claim_credit once the receiving account is ready.</div>' : ""}
    <details class="receipt-proof" ${verification.has(key(r)) || v.busy || v.result !== undefined || v.error ? "open" : ""}><summary>${icon("shield")}<span>Payment receipt</span><span class="proof-hash mono">${esc(r.hash.slice(0, 10))}…${esc(r.hash.slice(-6))}</span><span class="expand">+</span></summary><div class="proof-body"><div class="hash-row"><code class="${v.tamper ? "tampered-hash" : ""}">${esc(fullHash)}</code><button data-copy="${esc(fullHash)}" title="Copy receipt hash" aria-label="Copy receipt hash">${icon("copy")}</button></div><div class="proof-controls"><label class="tamper-switch"><input type="checkbox" data-tamper="${esc(key(r))}" ${v.tamper ? "checked" : ""}/><span class="switch"></span> Tamper with hash</label><button class="verify-button" data-verify="${esc(key(r))}" ${v.busy ? "disabled" : ""}>${v.busy ? "Verifying…" : "Verify receipt"}${icon("arrow")}</button></div>${v.result !== undefined ? `<div class="verify-result ${v.result ? "valid" : "invalid"}" role="status"><strong>${v.result ? "✓ Receipt verified" : "✗ Hash does not match"}</strong><span>${v.result ? "The contract confirms this exact hash." : "The contract rejected the changed hash. The stored receipt is unchanged."}</span></div>` : ""}${v.error ? `<div class="verify-result invalid" role="alert">RPC verification unavailable: ${esc(v.error)}</div>` : ""}<small class="proof-caption">verify_receipt · read-only simulation · settlement status: ${esc(r.status.kind)}</small></div></details></div>`;
}

function holdHtml(h: Hold) {
  const amount = h.escrow[deployment.eurd_token_id] ?? 0n;
  return `<article class="hold-card"><div class="hold-topline"><span class="status held">◷ Hold #${esc(h.id)}</span><span class="field-label">UK SOCIETY (DEMO)</span></div><div class="hold-amount">${money(amount)} <span>EURD</span></div><span class="reason-code">${esc(h.reason)}</span><p>${esc(h.note)}</p><div class="expiry-box"><div><span class="field-label">RELEASE UNLOCKS IN</span><strong class="countdown" data-expiry="${h.expires_at}">${countdown(h.expires_at)}</strong></div>${icon("clock")}</div><span class="expiry-date">Expiry: ${esc(new Date(h.expires_at * 1000).toLocaleString())}</span><button class="release-button" data-claim="${esc(h.id)}" data-unlock="${h.expires_at}" ${claimBusy || chainTime < h.expires_at ? "disabled" : ""}>${claimBusy ? "Processing…" : "Release my money"}${icon("arrow")}</button><small class="unlock-hint" data-hint="${h.expires_at}">Enabled once testnet confirms expiry.</small></article>`;
}

function bind() {
  document
    .querySelector<HTMLFormElement>("#address-form")!
    .addEventListener("submit", (e) => {
      e.preventDefault();
      void load(
        document
          .querySelector<HTMLInputElement>("#writer-address")!
          .value.trim(),
      );
    });
  document.querySelectorAll<HTMLButtonElement>("[data-writer]").forEach((b) =>
    b.addEventListener("click", () => {
      filter = "all";
      void load(deployment.accounts[b.dataset.writer!]);
    }),
  );
  document.querySelectorAll<HTMLButtonElement>("[data-filter]").forEach((b) =>
    b.addEventListener("click", () => {
      filter = b.dataset.filter!;
      render();
    }),
  );
  document
    .querySelector("#refresh")
    ?.addEventListener("click", () => void load(writer));
  document
    .querySelector("#retry")
    ?.addEventListener("click", () => void load(writer));
  document.querySelector("#signer-toggle")?.addEventListener("click", () => {
    showSigner = !showSigner;
    render();
  });
  document
    .querySelector<HTMLSelectElement>("#signer-mode")
    ?.addEventListener("change", (e) => {
      signing = (e.target as HTMLSelectElement).value as typeof signing;
      render();
    });
  const keyInput = document.querySelector<HTMLInputElement>("#demo-key");
  if (keyInput) {
    keyInput.value = demoSecret;
    keyInput.addEventListener("input", () => {
      demoSecret = keyInput.value.trim();
    });
  }
  document.querySelector("#connect")?.addEventListener("click", async () => {
    try {
      wallet = await connectFreighter();
      notice = `Connected ${short(wallet)} on testnet.`;
      error = "";
    } catch (e) {
      error = message(e);
    }
    render();
  });
  document.querySelectorAll<HTMLInputElement>("[data-tamper]").forEach((b) =>
    b.addEventListener("change", () => {
      verification.set(b.dataset.tamper!, { tamper: b.checked });
      render();
    }),
  );
  document.querySelectorAll<HTMLButtonElement>("[data-verify]").forEach((b) =>
    b.addEventListener("click", async () => {
      const id = b.dataset.verify!;
      const r = data?.receipts.find((r) => key(r) === id);
      if (!r) return;
      const v = verification.get(id) ?? { tamper: false };
      verification.set(id, {
        ...v,
        busy: true,
        result: undefined,
        error: undefined,
      });
      render();
      try {
        const result = await client.verify(r, v.tamper);
        verification.set(id, { tamper: v.tamper, result });
      } catch (e) {
        verification.set(id, { tamper: v.tamper, error: message(e) });
      }
      render();
    }),
  );
  document.querySelectorAll<HTMLButtonElement>("[data-copy]").forEach((b) =>
    b.addEventListener("click", async () => {
      try {
        await navigator.clipboard.writeText(b.dataset.copy!);
        b.title = "Copied";
        b.textContent = "✓";
      } catch {
        b.title = "Select and copy the hash manually";
      }
    }),
  );
  document
    .querySelectorAll<HTMLButtonElement>("[data-claim]")
    .forEach((b) =>
      b.addEventListener("click", () => void claim(b.dataset.claim!)),
    );
}
const message = (e: unknown) => (e instanceof Error ? e.message : String(e));
async function claim(id: string) {
  if (claimBusy) return;
  const hold = data?.holds.find((h) => h.id === id);
  if (!hold) return;
  if (signing === "demo" && !demoSecret) {
    showSigner = true;
    error =
      "Paste the demo writer-b testnet key under Release signing, or choose Freighter.";
    render();
    return;
  }
  claimBusy = true;
  error = "";
  notice = "Checking hold expiry on testnet…";
  render();
  try {
    const hash = await client.claim(
      hold,
      signing === "demo"
        ? { kind: "demo", secret: demoSecret }
        : { kind: "freighter" },
      (text) => {
        notice = text;
        render();
      },
    );
    notice = `Released to the writer. Testnet transaction: ${hash}`;
    await load(writer, true);
  } catch (e) {
    error = message(e);
    notice = "";
  } finally {
    claimBusy = false;
    render();
  }
}
async function load(address: string, quiet = false) {
  if (claimBusy && !quiet) return;
  if (!/^G[A-Z2-7]{55}$/.test(address)) {
    error =
      "Enter a valid Stellar account address beginning with G (56 characters).";
    render();
    return;
  }
  const version = ++loadVersion;
  if (address !== writer) {
    data = null;
    verification.clear();
  }
  writer = address;
  loading = !quiet;
  error = "";
  render();
  try {
    const result = await client.loadWriter(address);
    if (version !== loadVersion) return;
    data = result;
    chainTime = result.ledgerTime;
    clockOffset = result.ledgerTime - Date.now() / 1000;
    lastSync = new Date().toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch (e) {
    if (version === loadVersion) error = message(e);
  } finally {
    if (version === loadVersion) {
      loading = false;
      render();
    }
  }
}
function tick() {
  document.querySelectorAll<HTMLElement>("[data-expiry]").forEach((el) => {
    el.textContent = countdown(Number(el.dataset.expiry));
  });
  document
    .querySelectorAll<HTMLButtonElement>("[data-unlock]")
    .forEach((el) => {
      el.disabled = claimBusy || chainTime < Number(el.dataset.unlock);
    });
  document.querySelectorAll<HTMLElement>("[data-hint]").forEach((el) => {
    el.textContent =
      chainTime >= Number(el.dataset.hint)
        ? "Expired on-chain. You can release it now."
        : now() >= Number(el.dataset.hint)
          ? "Waiting for the next ledger to confirm expiry…"
          : "Enabled once testnet confirms expiry.";
  });
}
async function boot() {
  app.innerHTML =
    '<div class="boot"><img src="/mark.svg" alt="Royalty Rail"/><h1>Reading the rail.</h1><p>Connecting to Stellar testnet…</p></div>';
  try {
    deployment = await loadDeployment();
    client = new RailClient(deployment);
    const requested = new URLSearchParams(location.search).get("writer");
    writer = requested || deployment.accounts["writer-b"];
    render();
    await load(writer);
    setInterval(tick, 1000);
    setInterval(() => {
      if (!claimBusy && !loading && document.visibilityState === "visible")
        void load(writer, true);
    }, 20000);
    setInterval(async () => {
      try {
        const clock = await client.clock();
        chainTime = clock.time;
        clockOffset = clock.time - Date.now() / 1000;
        tick();
      } catch {
        /* RPC notices surface on full refresh; never unlock based on a failed clock read. */
      }
    }, 5000);
  } catch (e) {
    app.innerHTML = `<div class="boot"><h1>Connection unavailable.</h1><p>${esc(message(e))}</p><button onclick="location.reload()">Retry testnet connection</button></div>`;
  }
}
void boot();
