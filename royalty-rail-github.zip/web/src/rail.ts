import * as freighter from "@stellar/freighter-api";
import {
  Address,
  BASE_FEE,
  Contract,
  Keypair,
  Networks,
  StrKey,
  TransactionBuilder,
  nativeToScVal,
  rpc,
  scValToNative,
  xdr,
} from "@stellar/stellar-sdk";
import { Buffer } from "buffer";

/** The only network this client is allowed to contact. */
export const TESTNET_RPC_URL = "https://soroban-testnet.stellar.org";
const EVENT_PAGE_SIZE = 100;
const MAX_EVENT_PAGES = 100;
const HOLD_PAGE_SIZE = 20;
const MAX_PARALLEL_READS = 4;
const MAX_TRANSACTION_FEE = 4_294_967_295n;

/**
 * Deployment metadata published with the site. Extra deployment fields are
 * preserved because staging metadata is intentionally deployment-specific.
 */
export interface Deployment {
  network: string;
  rpc_url: string;
  network_passphrase: string;
  contract_id: string;
  eurd_token_id: string;
  accounts: Record<string, string>;
  statement_ids: string[];
  hold_ids?: string[];
  [key: string]: unknown;
}

export type ReceiptStatus =
  | { kind: "Paid"; holdId?: string }
  | { kind: "Held"; holdId: string }
  | { kind: "Credited"; holdId?: string };

/** A receipt normalized from the contract's Soroban value. */
export interface Receipt {
  statement_id: string;
  line_index: number;
  work_id: string;
  work_version: number;
  payee: string;
  role: string;
  amount: bigint;
  territory: string;
  period: string;
  source: string;
  society: string;
  token: string;
  status: ReceiptStatus;
  settled_at: number;
  /** Lowercase, 64-character hexadecimal SHA-256 receipt hash. */
  hash: string;
}

/** A hold normalized from the contract's Soroban value. */
export interface Hold {
  id: string;
  expires_at: number;
  placed_at: number;
  open: boolean;
  escrow: Record<string, bigint>;
  reason: string;
  note: string;
  payee: string;
  society: string;
  work_id?: string;
}

export interface WriterData {
  receipts: Receipt[];
  holds: Hold[];
  statementIds: string[];
  discovery: "events" | "fallback" | "mixed";
  ledger: number;
  ledgerTime: number;
  warnings: string[];
}

type Signing =
  | { kind: "demo"; secret: string }
  | { kind: "freighter" };

type NativeRecord = Record<string, unknown>;

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function isRecord(value: unknown): value is NativeRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function requiredRecord(value: unknown, name: string): NativeRecord {
  if (!isRecord(value)) {
    throw new TypeError(`Unexpected ${name} value returned by the contract.`);
  }
  return value;
}

/** Convert SDK text output (including a binary string fallback) to UTF-8. */
function text(value: unknown, field: string): string {
  if (typeof value === "string") return value;
  if (value instanceof Uint8Array) return Buffer.from(value).toString("utf8");
  throw new TypeError(`Unexpected ${field} value returned by the contract.`);
}

function bigintValue(value: unknown, field: string): bigint {
  if (typeof value === "bigint") return value;
  if (typeof value === "number" && Number.isSafeInteger(value)) return BigInt(value);
  if (typeof value === "string" && /^-?\d+$/.test(value)) return BigInt(value);
  throw new TypeError(`Unexpected ${field} integer returned by the contract.`);
}

function safeNumber(value: unknown, field: string): number {
  const parsed = bigintValue(value, field);
  if (parsed > BigInt(Number.MAX_SAFE_INTEGER) || parsed < BigInt(Number.MIN_SAFE_INTEGER)) {
    throw new RangeError(`${field} cannot be represented safely as a JavaScript number.`);
  }
  return Number(parsed);
}

function u32(value: number, field: string): xdr.ScVal {
  if (!Number.isInteger(value) || value < 0 || value > 0xffff_ffff) {
    throw new RangeError(`${field} must be a u32.`);
  }
  return nativeToScVal(value, { type: "u32" });
}

function u64(value: string | bigint, field: string): xdr.ScVal {
  const parsed = typeof value === "bigint" ? value : BigInt(value);
  if (parsed < 0n || parsed > 0xffff_ffff_ffff_ffffn) {
    throw new RangeError(`${field} must be a u64.`);
  }
  return nativeToScVal(parsed, { type: "u64" });
}

function addressScVal(address: string): xdr.ScVal {
  if (!StrKey.isValidEd25519PublicKey(address)) {
    throw new TypeError(`Expected an Ed25519 account address, got ${address}.`);
  }
  return new Address(address).toScVal();
}

function normalizeStatus(value: unknown): ReceiptStatus {
  if (!Array.isArray(value) || value.length < 1) {
    throw new TypeError("Unexpected receipt status returned by the contract.");
  }

  const kind = text(value[0], "receipt status kind");
  switch (kind) {
    case "Paid":
      return { kind: "Paid" };
    case "Credited":
      return { kind: "Credited" };
    case "Held":
      if (value.length < 2) {
        throw new TypeError("Held receipt status is missing its hold ID.");
      }
      return { kind: "Held", holdId: bigintValue(value[1], "hold ID").toString() };
    default:
      throw new TypeError(`Unknown receipt status ${kind}.`);
  }
}

function normalizeReceipt(value: unknown): Receipt {
  const record = requiredRecord(value, "receipt");
  const hash = record.hash;
  if (!(hash instanceof Uint8Array) || hash.length !== 32) {
    throw new TypeError("Unexpected receipt hash returned by the contract.");
  }

  return {
    statement_id: text(record.statement_id, "statement_id"),
    line_index: safeNumber(record.line_index, "line_index"),
    work_id: text(record.work_id, "work_id"),
    work_version: safeNumber(record.work_version, "work_version"),
    payee: text(record.payee, "payee"),
    role: text(record.role, "role"),
    amount: bigintValue(record.amount, "amount"),
    territory: text(record.territory, "territory"),
    period: text(record.period, "period"),
    source: text(record.source, "source"),
    society: text(record.society, "society"),
    token: text(record.token, "token"),
    status: normalizeStatus(record.status),
    settled_at: safeNumber(record.settled_at, "settled_at"),
    hash: Buffer.from(hash).toString("hex").toLowerCase(),
  };
}

function normalizeHold(value: unknown): Hold {
  const record = requiredRecord(value, "hold");
  const rawEscrow = requiredRecord(record.escrow, "hold escrow");
  const escrow: Record<string, bigint> = {};
  for (const [token, amount] of Object.entries(rawEscrow)) {
    escrow[token] = bigintValue(amount, `escrow amount for ${token}`);
  }

  const rawWorkId = record.work_id;
  const workId = rawWorkId === null || rawWorkId === undefined
    ? undefined
    : text(rawWorkId, "work_id");

  return {
    id: bigintValue(record.id, "hold ID").toString(),
    expires_at: safeNumber(record.expires_at, "expires_at"),
    placed_at: safeNumber(record.placed_at, "placed_at"),
    open: Boolean(record.open),
    escrow,
    reason: text(record.reason, "reason"),
    note: text(record.note, "note"),
    payee: text(record.payee, "payee"),
    society: text(record.society, "society"),
    ...(workId === undefined ? {} : { work_id: workId }),
  };
}

function asScVal(argument: xdr.ScVal | unknown): xdr.ScVal {
  return xdr.ScVal.is(argument) ? argument : nativeToScVal(argument);
}

function assertDeployment(deployment: Deployment): void {
  if (deployment.network !== "testnet") {
    throw new Error("Royalty Rail is testnet-only; deployment.network must be testnet.");
  }
  if (deployment.rpc_url !== TESTNET_RPC_URL) {
    throw new Error(`Royalty Rail is pinned to ${TESTNET_RPC_URL}.`);
  }
  if (deployment.network_passphrase !== Networks.TESTNET) {
    throw new Error("Royalty Rail requires Networks.TESTNET.");
  }
  if (!StrKey.isValidContract(deployment.contract_id)) {
    throw new TypeError("deployment.contract_id is not a valid Soroban contract ID.");
  }
  if (!StrKey.isValidContract(deployment.eurd_token_id)) {
    throw new TypeError("deployment.eurd_token_id is not a valid Soroban contract ID.");
  }
  if (!deployment.accounts || !Array.isArray(deployment.statement_ids)) {
    throw new TypeError("deployment is missing accounts or statement_ids.");
  }
}

/** Load the browser-published deployment descriptor. */
export async function loadDeployment(): Promise<Deployment> {
  const response = await fetch("/deployment.json");
  if (!response.ok) {
    throw new Error(`Could not load /deployment.json (${response.status}).`);
  }
  const deployment = (await response.json()) as Deployment;
  assertDeployment(deployment);
  return deployment;
}

/** Connect to Freighter only when its selected network is exactly testnet. */
export async function connectFreighter(): Promise<string> {
  const access = await freighter.requestAccess();
  if (access.error || !access.address) {
    throw new Error(`Freighter connection failed: ${String(access.error ?? "no address returned")}`);
  }

  const network = await freighter.getNetwork();
  if (network.error || network.networkPassphrase !== Networks.TESTNET) {
    throw new Error("Freighter must be switched to Stellar testnet before signing.");
  }
  if (!StrKey.isValidEd25519PublicKey(access.address)) {
    throw new Error("Freighter returned an unsupported or invalid source account.");
  }
  return access.address;
}

/**
 * A small read/write client for the deployed Royalty Rail contract.
 * It deliberately pins every network primitive to Stellar testnet.
 */
export class RailClient {
  public readonly deployment: Deployment;
  private readonly server: rpc.Server;
  private readonly contract: Contract;
  private readonly readSource: string;

  public constructor(deployment: Deployment) {
    assertDeployment(deployment);
    this.deployment = deployment;
    this.server = new rpc.Server(TESTNET_RPC_URL, { timeout: 30_000 });
    this.contract = new Contract(deployment.contract_id);

    const demoWriter = deployment.accounts["writer-a"];
    const admin = deployment.accounts.admin;
    const source = demoWriter ?? admin;
    if (!source || !StrKey.isValidEd25519PublicKey(source)) {
      throw new Error("A valid demo writer-a or admin account is required for simulation reads.");
    }
    this.readSource = source;
  }

  /** Simulate a view call only; this method never signs or submits a read. */
  public async read(method: string, args: readonly (xdr.ScVal | unknown)[] = []): Promise<unknown> {
    const account = await this.server.getAccount(this.readSource);
    const transaction = new TransactionBuilder(account, {
      fee: BASE_FEE,
      networkPassphrase: Networks.TESTNET,
    })
      .addOperation(this.contract.call(method, ...args.map(asScVal)))
      .setTimeout(30)
      .build();

    const simulation = await this.server.simulateTransaction(transaction);
    if ("error" in simulation && simulation.error) {
      throw new Error(`Simulation of ${method} failed: ${simulation.error}`);
    }
    if (!("result" in simulation) || !simulation.result) {
      throw new Error(`Simulation of ${method} returned no result.`);
    }
    return scValToNative(simulation.result.retval);
  }

  /** Return the current on-chain ledger and close timestamp. */
  public async clock(): Promise<{ ledger: number; time: number }> {
    const latest = await this.server.getLatestLedger();
    const time = Number(latest.closeTime);
    if (!Number.isSafeInteger(time)) {
      throw new RangeError("The current ledger close time cannot be represented safely.");
    }
    return { ledger: latest.sequence, time };
  }

  /**
   * Read event-indexed statement IDs for a payee. The first two filter topics
   * are encoded XDR base64; topic 2 is wildcarded and decoded as an scvString.
   */
  private async discoverStatementIds(address: string): Promise<{
    ids: string[];
    warnings: string[];
  }> {
    const symbol = xdr.ScVal.scvSymbol("payee_settled").toXdr("base64");
    const payee = addressScVal(address).toXdr("base64");
    const filters: rpc.Api.EventFilter[] = [{
      type: "contract",
      contractIds: [this.deployment.contract_id],
      topics: [[symbol, payee, "*"]],
    }];

    const latest = await this.server.getLatestLedger();
    const health = await this.server.getHealth();
    const startLedger = health.oldestLedger;
    const ids = new Set<string>();
    const warnings: string[] = [];
    let page = await this.server.getEvents({
      startLedger,
      filters,
      limit: EVENT_PAGE_SIZE,
    });

    for (let pageNumber = 0; ; pageNumber += 1) {
      for (const event of page.events) {
        const statementTopic = event.topic[2];
        if (!statementTopic || statementTopic.type !== "scvString") {
          warnings.push(`Ignored malformed payee_settled event ${event.id}: topic 2 is not scvString.`);
          continue;
        }
        ids.add(text(scValToNative(statementTopic), "payee_settled statement_id"));
      }

      // RPC bounds the scanned ledger range, so an empty/short page can still
      // precede newer matching events. Continue until the TOID cursor reaches
      // the ledger snapshot, not merely until an event page is shorter than 100.
      const scannedLedger = Number(BigInt(page.cursor.split("-")[0]!) >> 32n);
      if (scannedLedger >= latest.sequence) break;
      if (pageNumber + 1 >= MAX_EVENT_PAGES) {
        warnings.push("Stopped event discovery after the configured page limit.");
        break;
      }
      page = await this.server.getEvents({
        cursor: page.cursor,
        filters,
        limit: EVENT_PAGE_SIZE,
      });
    }

    return { ids: [...ids], warnings };
  }

  private async loadHolds(address: string): Promise<Hold[]> {
    const count = safeNumber(
      await this.read("hold_count", [addressScVal(address)]),
      "hold_count",
    );
    const starts = Array.from(
      { length: Math.ceil(count / HOLD_PAGE_SIZE) },
      (_, page) => page * HOLD_PAGE_SIZE,
    );

    const pages = await mapWithConcurrency(starts, MAX_PARALLEL_READS, async (start) => {
      const values = await this.read("holds_for", [
        addressScVal(address),
        u32(start, "hold history start"),
        u32(HOLD_PAGE_SIZE, "hold history limit"),
      ]);
      if (!Array.isArray(values)) {
        throw new TypeError("holds_for returned a non-vector value.");
      }
      return values.map(normalizeHold);
    });

    return pages.flat().sort((left, right) => BigInt(left.id) < BigInt(right.id) ? -1 : 1);
  }

  /** Load all known receipts and full hold history for a writer. */
  public async loadWriter(address: string): Promise<WriterData> {
    addressScVal(address);
    const warnings: string[] = [];
    const [currentClock, discovery, holds] = await Promise.all([
      this.clock(),
      this.discoverStatementIds(address).catch((error: unknown) => ({
        ids: [] as string[],
        warnings: [`Event discovery unavailable: ${errorMessage(error)}`],
      })),
      this.loadHolds(address),
    ]);
    warnings.push(...discovery.warnings);

    const eventIds = new Set(discovery.ids);
    const fallbackIds = this.deployment.statement_ids.filter((id) => !eventIds.has(id));
    const statementIds = [...eventIds, ...fallbackIds];
    const discoveryKind: WriterData["discovery"] = eventIds.size === 0
      ? "fallback"
      : fallbackIds.length === 0
        ? "events"
        : "mixed";
    if (eventIds.size === 0 && fallbackIds.length > 0) {
      warnings.push("No indexed payee_settled events were returned; using deployment statement IDs as fallback.");
    }

    const receiptPages = await mapWithConcurrency(
      statementIds,
      MAX_PARALLEL_READS,
      async (statementId) => {
        try {
          const values = await this.read("statement_receipts", [
            nativeToScVal(statementId, { type: "string" }),
          ]);
          if (!Array.isArray(values)) {
            throw new TypeError("statement_receipts returned a non-vector value.");
          }
          return values.map(normalizeReceipt).filter((receipt) => receipt.payee === address);
        } catch (error) {
          warnings.push(`Could not load statement ${statementId}: ${errorMessage(error)}`);
          return [] as Receipt[];
        }
      },
    );

    const receipts = receiptPages.flat().sort((left, right) => {
      const statementOrder = left.statement_id.localeCompare(right.statement_id);
      return statementOrder === 0 ? left.line_index - right.line_index : statementOrder;
    });

    return {
      receipts,
      holds,
      statementIds: [...new Set(receipts.map((receipt) => receipt.statement_id))],
      discovery: discoveryKind,
      ledger: currentClock.ledger,
      ledgerTime: currentClock.time,
      warnings,
    };
  }

  /** Verify the receipt hash against the contract's stored receipt. */
  public async verify(receipt: Receipt, tampered = false): Promise<boolean> {
    if (!/^[0-9a-f]{64}$/i.test(receipt.hash)) {
      throw new TypeError("Receipt hash must be 32 bytes encoded as hexadecimal.");
    }
    const hex = tampered
      ? `${receipt.hash[0] === "0" ? "1" : "0"}${receipt.hash.slice(1)}`
      : receipt.hash;
    const hash = Buffer.from(hex, "hex");

    const verified = await this.read("verify_receipt", [
      nativeToScVal(receipt.statement_id, { type: "string" }),
      u32(receipt.line_index, "receipt line_index"),
      addressScVal(receipt.payee),
      nativeToScVal(hash, { type: "bytes" }),
    ]);
    if (typeof verified !== "boolean") {
      throw new TypeError("verify_receipt returned a non-boolean value.");
    }
    return verified;
  }

  /** Connect to Freighter only when its selected network is exactly testnet. */
  public async connectFreighter(): Promise<string> {
    return connectFreighter();
  }

  /**
   * Submit a claim_expired transaction only after refreshing the hold and
   * checking its expiration against the network ledger clock.
   */
  public async claim(
    hold: Hold,
    signing: Signing,
    onProgress?: (text: string) => void,
  ): Promise<string> {
    const initialClock = await this.clock();
    if (initialClock.time < hold.expires_at) {
      throw new Error("This hold has not expired on the current network ledger.");
    }

    const refreshed = normalizeHold(await this.read("get_hold", [u64(hold.id, "hold ID")]));
    const refreshedClock = await this.clock();
    if (!refreshed.open) throw new Error("This hold is already closed on-chain.");
    if (refreshedClock.time < refreshed.expires_at) {
      throw new Error("The refreshed on-chain hold has not expired yet.");
    }

    let source: string;
    let demoKeypair: Keypair | undefined;
    if (signing.kind === "demo") {
      const demoWriter = this.deployment.accounts["writer-b"];
      if (!demoWriter) throw new Error("This deployment has no demo writer-b account.");
      try {
        demoKeypair = Keypair.fromSecret(signing.secret);
      } catch {
        throw new Error("The supplied demo signing secret is invalid.");
      }
      if (demoKeypair.publicKey() !== demoWriter) {
        throw new Error("Demo signing is restricted to the deployment's writer-b account.");
      }
      source = demoWriter;
    } else {
      source = await this.connectFreighter();
    }

    onProgress?.("Preparing expired-hold claim on Stellar testnet…");
    const account = await this.server.getAccount(source);
    const unsigned = new TransactionBuilder(account, {
      fee: BASE_FEE,
      networkPassphrase: Networks.TESTNET,
    })
      .addOperation(this.contract.call("claim_expired", u64(refreshed.id, "hold ID")))
      .setTimeout(60)
      .build();

    let prepared;
    try {
      prepared = await this.server.prepareTransaction(unsigned);
    } catch (error) {
      throw new Error(`Could not prepare the claim (including its Soroban fee): ${errorMessage(error)}`);
    }
    if (BigInt(prepared.fee) > MAX_TRANSACTION_FEE) {
      throw new Error(
        "The prepared claim exceeds Stellar's uint32 transaction-fee limit. " +
          "Do not submit it; refresh the transaction or use a supported fee-bump flow.",
      );
    }

    let signed;
    if (signing.kind === "demo") {
      prepared.sign(demoKeypair!);
      signed = prepared;
    } else {
      onProgress?.("Requesting an explicit Stellar testnet signature from Freighter…");
      const response = await freighter.signTransaction(prepared.toXdr(), {
        address: source,
        networkPassphrase: Networks.TESTNET,
      });
      if (response.error || !response.signedTxXdr) {
        throw new Error(`Freighter did not sign the claim: ${String(response.error ?? "no signed XDR returned")}`);
      }
      if (response.signerAddress && response.signerAddress !== source) {
        throw new Error("Freighter signed with a different account than the connected testnet account.");
      }
      signed = TransactionBuilder.fromXDR(response.signedTxXdr, Networks.TESTNET);
    }

    onProgress?.("Submitting claim to Stellar testnet…");
    const submitted = await this.server.sendTransaction(signed);
    const hash = submitted.hash;
    if (submitted.status === "ERROR") {
      throw new Error(`Claim was rejected before submission: ${submitted.errorResult?.toXdr("base64") ?? "RPC rejected the transaction"}`);
    }
    if (submitted.status === "TRY_AGAIN_LATER") {
      throw new Error("Claim was not accepted by the network yet. It was not automatically resubmitted.");
    }

    onProgress?.(`Claim submitted (${hash}). Waiting for a final result…`);
    for (let attempt = 0; attempt < 30; attempt += 1) {
      await sleep(1_000);
      const result = await this.server.getTransaction(hash);
      if (result.status === rpc.Api.GetTransactionStatus.SUCCESS) {
        onProgress?.("Claim confirmed on Stellar testnet.");
        return hash;
      }
      if (result.status === rpc.Api.GetTransactionStatus.FAILED) {
        throw new Error("Claim reached the network but failed. It will not be automatically resubmitted.");
      }
    }

    onProgress?.(`Claim ${hash} is submitted but still pending; it was not automatically resubmitted.`);
    throw new Error(`Claim ${hash} is submitted but still pending. Check its testnet transaction result before trying again; payment is not yet confirmed.`);
  }
}

async function mapWithConcurrency<T, R>(
  values: readonly T[],
  concurrency: number,
  task: (value: T) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(values.length);
  let nextIndex = 0;
  const workers = Array.from({ length: Math.min(concurrency, values.length) }, async () => {
    while (true) {
      const index = nextIndex;
      nextIndex += 1;
      if (index >= values.length) return;
      results[index] = await task(values[index]!);
    }
  });
  await Promise.all(workers);
  return results;
}

function sleep(milliseconds: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}
