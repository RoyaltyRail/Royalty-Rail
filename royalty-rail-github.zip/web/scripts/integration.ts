import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import {
  RailClient,
  type Deployment,
  type Receipt,
  TESTNET_RPC_URL,
} from "../src/rail.ts";

const deploymentPath = fileURLToPath(new URL("../public/deployment.json", import.meta.url));
const deployment = JSON.parse(await readFile(deploymentPath, "utf8")) as Deployment;

assert.equal(deployment.network, "testnet", "integration only permits testnet");
assert.equal(deployment.rpc_url, TESTNET_RPC_URL, "integration only permits pinned testnet RPC");

const client = new RailClient(deployment);
const writerAAddress = deployment.accounts["writer-a"];
const writerBAddress = deployment.accounts["writer-b"];
assert.ok(writerAAddress, "writer-a must be present in deployment metadata");
assert.ok(writerBAddress, "writer-b must be present in deployment metadata");

const [writerA, writerB] = await Promise.all([
  client.loadWriter(writerAAddress),
  client.loadWriter(writerBAddress),
]);

assert.ok(writerA.receipts.length > 0, "writer-a must have live on-chain receipts");
assert.ok(writerB.receipts.length > 0, "writer-b must have live on-chain receipts");
assert.equal(writerA.receipts.every((receipt) => receipt.payee === writerAAddress), true);
assert.equal(writerB.receipts.every((receipt) => receipt.payee === writerBAddress), true);
assert.equal(writerA.receipts.every((receipt) => typeof receipt.amount === "bigint"), true);
assert.equal(writerB.receipts.every((receipt) => /^[0-9a-f]{64}$/.test(receipt.hash)), true);

const receiptToVerify: Receipt = writerA.receipts[0]!;
assert.equal(await client.verify(receiptToVerify), true, "stored receipt hash must verify");
assert.equal(await client.verify(receiptToVerify, true), false, "tampered receipt hash must fail");

const configuredStage = deployment.stage as
  | { statement_id?: string; hold_id?: string; total_held?: string }
  | undefined;
const stageStatementId = configuredStage?.statement_id ?? (deployment.stage_statement_id as string | undefined);
const stageHoldId = configuredStage?.hold_id ?? (deployment.stage_hold_id as string | undefined);
assert.ok(stageStatementId, "staged statement ID must be present in deployment metadata");
assert.ok(stageHoldId, "staged hold ID must be present in deployment metadata");

const stagedHold = writerB.holds.find((hold) => hold.id === stageHoldId);
assert.ok(stagedHold, "writer-b full hold history must include the staged hold");
assert.equal(stagedHold.payee, writerBAddress);
assert.equal(stagedHold.reason, "MISSING_DATA");
assert.equal(stagedHold.expires_at - stagedHold.placed_at, 120, "stage hold is exactly two minutes");

// Test event discovery with no fallback IDs at all. This catches RPCs that
// return empty bounded ledger scans before the recent matching events.
const eventOnly = await new RailClient({ ...deployment, statement_ids: [] }).loadWriter(writerBAddress);
assert.equal(eventOnly.discovery, "events", "indexed event discovery must work independently");
assert.ok(eventOnly.receipts.some((receipt) => receipt.statement_id === stageStatementId));

const stagedHeldReceipts = writerB.receipts.filter(
  (receipt) => receipt.statement_id === stageStatementId && receipt.status.kind === "Held",
);
assert.ok(stagedHeldReceipts.length > 0, "staged statement must contain writer-b Held receipt lines");
assert.equal(
  stagedHeldReceipts.every((receipt) => receipt.status.holdId === stageHoldId),
  true,
  "each staged Held receipt must reference the staged hold",
);
if (configuredStage?.total_held !== undefined) {
  const heldTotal = stagedHeldReceipts.reduce((sum, receipt) => sum + receipt.amount, 0n);
  assert.equal(heldTotal, BigInt(configuredStage.total_held));
}

const clock = await client.clock();
assert.ok(clock.ledger > 0 && clock.time > 0, "live RPC clock must return a ledger and ledger time");

console.log(
  JSON.stringify(
    {
      rpc: TESTNET_RPC_URL,
      ledger: clock.ledger,
      ledgerTime: clock.time,
      writerA: {
        receipts: writerA.receipts.length,
        discovery: writerA.discovery,
        warnings: writerA.warnings,
      },
      writerB: {
        receipts: writerB.receipts.length,
        holds: writerB.holds.length,
        discovery: writerB.discovery,
        stagedHeldReceipts: stagedHeldReceipts.length,
        stagedHoldOpen: stagedHold.open,
        warnings: writerB.warnings,
      },
      receiptVerification: { valid: true, tampered: false },
    },
    null,
    2,
  ),
);
