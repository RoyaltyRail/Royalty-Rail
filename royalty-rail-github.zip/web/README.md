# Royalty Rail — Writer statement

A responsive, single-page statement reader for the existing Royalty Rail Soroban contract. All RPC calls and signing are pinned to Stellar **testnet**. EURD is a demo asset, not EURC and not real money.

## Run locally

Use Node 22.12+ and the pinned pnpm version. Run `corepack pnpm install --frozen-lockfile`, then `corepack pnpm dev`. Open localhost:3000. `corepack pnpm build` produces static files in `dist`.

The page loads the public contract, account addresses, token, and fallback statement IDs from `public/deployment.json`. It discovers new statements from the `payee_settled` event using the indexed writer address topic. Demo statement IDs supplement the event feed when RPC retention limits or errors prevent discovery. Receipts and holds themselves are read live from the testnet RPC, not from fixtures.

## Verify and release

Expand **Payment receipt**, then select **Verify receipt**. The result comes from a read-only `verify_receipt` simulation. The tamper toggle changes the first hash character and calls the same contract function; it does not change the stored receipt.

For release, select Writer B and open **Release signing**. Paste only the generated writer-b key from `demo/demo-keys.json` in the enclosing contract repository, or choose Freighter with its network set to testnet. Secret-key input stays in browser memory only and is not logged, persisted, or sent to an application server. The published website has no private keys.

Release unlocks only once a current testnet ledger confirms expiry. `claim_expired` itself requires no contract authorization, but the network transaction needs a fee-payer signature. The recipient is fixed by the contract; signing does not let someone redirect the escrow.

A receipt is an immutable settlement record. After an escrow is released, the page shows current Paid status and explains that the original receipt remains Held. Credited receipts likewise describe their settlement outcome, not an assertion that funds remain unclaimed forever.

## Stage preparation

Run `./demo/stage.sh` in the enclosing contract repository immediately before presenting. It places a fresh 120-second MISSING_DATA hold, settles a uniquely named statement, and updates deployment.json. The public page's event feed discovers new stage statements without a republish. Click Refresh or wait for the automatic 20-second refresh.

## Checks and sources

`corepack pnpm check` checks TypeScript. `corepack pnpm test:integration` checks live statement discovery, receipt verification, tamper rejection, and holds without moving funds. The integration script uses public deployment data; private keys are not necessary.

SDK: https://stellar.github.io/js-stellar-sdk/

RPC event filtering: https://developers.stellar.org/docs/data/apis/rpc/api-reference/methods/getEvents

Simulation: https://developers.stellar.org/docs/build/guides/transactions/simulateTransaction-Deep-Dive

Typography: IBM Plex Sans and IBM Plex Mono from Google Fonts, self-hosted under public/fonts. No society names or logos are used.
