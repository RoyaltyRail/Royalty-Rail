#!/usr/bin/env bash
# Royalty Rail — TESTNET ONLY. All assets and XLM are Friendbot/demo funds.
# Run from the repo root: ./demo/run-demo.sh
set -euo pipefail
cd "$(dirname "$0")/.."
source "$HOME/.cargo/env" 2>/dev/null || true
unset STELLAR_RPC_URL STELLAR_NETWORK_PASSPHRASE STELLAR_NETWORK STELLAR_ACCOUNT STELLAR_SIGN_WITH_KEY STELLAR_SEND
RPC=https://soroban-testnet.stellar.org
PASSPHRASE='Test SDF Network ; September 2015'
NET=(--network testnet --rpc-url "$RPC" --network-passphrase "$PASSPHRASE")
ISWC=T-900.000.001-0
DEPLOYMENT=deployment.json
step() { printf '\n▶ %s\n' "$*"; }
update() { local tmp; tmp=$(mktemp); jq "$@" "$DEPLOYMENT" > "$tmp"; mv "$tmp" "$DEPLOYMENT"; }

step '1. Accounts (funded by Friendbot)'
for who in admin uk-society writer-a writer-b publisher; do
  if ! stellar keys address "$who" >/dev/null 2>&1; then
    stellar keys generate "$who" "${NET[@]}" --fund
  fi
done
ADMIN=$(stellar keys address admin)
UK=$(stellar keys address uk-society)
WA=$(stellar keys address writer-a)
WB=$(stellar keys address writer-b)
PUB=$(stellar keys address publisher)
if [[ ! -f "$DEPLOYMENT" ]]; then
  jq -n --arg admin "$ADMIN" --arg uk "$UK" --arg wa "$WA" --arg wb "$WB" --arg pub "$PUB" --arg rpc "$RPC" --arg pass "$PASSPHRASE" --arg work "$ISWC" \
    '{network:"testnet",rpc_url:$rpc,network_passphrase:$pass,accounts:{admin:$admin,"uk-society":$uk,"writer-a":$wa,"writer-b":$wb,publisher:$pub},work_id:$work,contract_id:null,eurd_token_id:null,statement_ids:[],hold_ids:[],completed:[]}' > "$DEPLOYMENT"
fi
jq -e --arg a "$ADMIN" '.network == "testnet" and .accounts.admin == $a' "$DEPLOYMENT" >/dev/null
# The current testnet WASM rent can exceed the 10,000 XLM Friendbot grant.
# Pool only generated demo accounts' free test XLM; leave 5,000 on each payer.
if ! jq -e '.completed | index("fund-admin") != null' "$DEPLOYMENT" >/dev/null; then
  for who in uk-society writer-a writer-b publisher; do
    stellar tx new payment --source "$who" "${NET[@]}" --destination "$ADMIN" --amount 50000000000 >/dev/null
  done
  update '.completed += ["fund-admin"]'
fi

done_step() { jq -e --arg s "$1" '.completed | index($s) != null' "$DEPLOYMENT" >/dev/null; }
mark() { update --arg s "$1" '.completed += [$s]'; }
step '2. Demo euro token EURD (not EURC)'
EURD=$(stellar contract id asset --asset "EURD:$ADMIN" "${NET[@]}")
if ! done_step token; then
  if ! stellar contract invoke --id "$EURD" --source admin "${NET[@]}" --send=no -- name >/dev/null 2>&1; then
    stellar contract asset deploy --asset "EURD:$ADMIN" --source admin "${NET[@]}" --alias eurd
  fi
  for who in uk-society writer-a writer-b publisher; do
    stellar tx new change-trust --source "$who" --line "EURD:$ADMIN" "${NET[@]}" >/dev/null
  done
  stellar contract invoke --id "$EURD" --source admin "${NET[@]}" -- mint --to "$UK" --amount 1000000000000
  update --arg t "$EURD" '.eurd_token_id=$t'
  mark token
fi

step '3. Build and deploy Royalty Rail'
stellar contract build
WASM=target/wasm32v1-none/release/royalty_rail.wasm
[[ $(stat -c %s "$WASM") -lt 64000 ]]
RAIL=$(jq -r '.contract_id // empty' "$DEPLOYMENT")
if [[ -z "$RAIL" ]]; then
  ./demo/fund-testnet.sh admin 250000
  RAIL=$(stellar contract deploy --wasm "$WASM" --source admin "${NET[@]}" --alias royalty-rail -- --admin "$ADMIN")
  update --arg c "$RAIL" --arg t "$EURD" '.contract_id=$c | .eurd_token_id=$t'
fi
echo "Royalty Rail: $RAIL"
rail() { stellar contract invoke --id "$RAIL" "${NET[@]}" "$@"; }
if ! done_step allowlist; then
  ./demo/fund-testnet.sh admin 100000
  rail --source admin -- add_society --society "$UK" --name 'UK society (demo)'
  rail --source admin -- add_token --token "$EURD"
  mark allowlist
fi

step '4. Register work and accept splits'
if ! done_step work; then
  ./demo/fund-testnet.sh publisher 250000
  ./demo/fund-testnet.sh writer-a 100000
  ./demo/fund-testnet.sh writer-b 100000
  rail --source publisher -- register_work --registrant "$PUB" --work_id "$ISWC" --title 'Demo Track' \
    --shares "[{\"payee\":\"$WA\",\"bps\":4000,\"role\":\"WRITER\"},{\"payee\":\"$WB\",\"bps\":3500,\"role\":\"WRITER\"},{\"payee\":\"$PUB\",\"bps\":2500,\"role\":\"PUBLISHER\"}]"
  rail --source writer-a -- accept_splits --payee "$WA" --work_id "$ISWC"
  rail --source writer-b -- accept_splits --payee "$WB" --work_id "$ISWC"
  mark work
fi
rail --source admin --send=no -- get_work --work_id "$ISWC"

step '5. Settle Q3 — a receipt per line'
if ! done_step q3; then
  ./demo/fund-testnet.sh uk-society 500000
  rail --source uk-society -- settle --society "$UK" --token "$EURD" --statement_id UK-2027Q3-0001 --lines "$(jq -c '.lines' demo/statement-2027Q3.json)"
  update '.statement_ids = ((.statement_ids + ["UK-2027Q3-0001"]) | unique)'
  mark q3
fi
HASH=$(rail --source admin --send=no -- get_receipt --statement_id UK-2027Q3-0001 --line_index 0 --payee "$WA" | jq -r '.hash')
echo "Receipt hash: $HASH"
rail --source admin --send=no -- verify_receipt --statement_id UK-2027Q3-0001 --line_index 0 --payee "$WA" --hash "$HASH"

step '6. Hold writer-b for 120 seconds; settle Q4'
HOLD=$(jq -r '.demo_hold_id // empty' "$DEPLOYMENT")
if [[ -z "$HOLD" ]]; then
  ./demo/fund-testnet.sh uk-society 500000
  HOLD=$(rail --source uk-society -- place_hold --society "$UK" --payee "$WB" --work_id "$(jq -cn --arg w "$ISWC" '$w')" --reason MISSING_DATA --note "Bank details on file don't match the member record (demo)" --duration_secs 120 | jq -r '.')
  update --arg h "$HOLD" '.demo_hold_id=$h | .hold_ids += [$h]'
fi
if ! done_step q4; then
  rail --source uk-society -- settle --society "$UK" --token "$EURD" --statement_id UK-2027Q4-0001 --lines "$(jq -c '.lines' demo/statement-2027Q4.json)"
  update '.statement_ids = ((.statement_ids + ["UK-2027Q4-0001"]) | unique)'
  mark q4
fi
rail --source admin --send=no -- holds_for --payee "$WB" --start 0 --limit 20

step '7. Wait for on-chain expiry; writer-b releases without society consent'
if ! done_step claimed; then
  EXPIRY=$(rail --source admin --send=no -- get_hold --hold_id "$HOLD" | jq -r '.expires_at')
  # Ledger time, not a fixed sleep: avoid submitting before expiry.
  while :; do
    CLOSED=$(curl -fsSL 'https://horizon-testnet.stellar.org/ledgers?order=desc&limit=1' | jq -r '._embedded.records[0].closed_at')
    NOW=$(date -d "$CLOSED" +%s)
    (( NOW >= EXPIRY )) && break
    echo "Hold expires in $((EXPIRY-NOW)) seconds (ledger time)"
    sleep 6
  done
  rail --source writer-b -- claim_expired --hold_id "$HOLD"
  mark claimed
fi
for who in writer-a writer-b publisher; do
  printf '%-10s ' "$who"
  stellar contract invoke --id "$EURD" "${NET[@]}" --source admin --send=no -- balance --id "$(stellar keys address "$who")"
done
update --arg time "$(date -u +%FT%TZ)" '.deployed_at = (.deployed_at // $time)'
step "Done. Royalty Rail: $RAIL   EURD: $EURD; saved deployment.json"
