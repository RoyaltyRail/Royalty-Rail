#!/usr/bin/env bash
# TESTNET ONLY: refill generated faucet accounts and pool free test XLM.
# Usage: ./demo/fund-testnet.sh <stellar-key-alias> <minimum-XLM>
set -euo pipefail
cd "$(dirname "$0")/.."
unset STELLAR_RPC_URL STELLAR_NETWORK_PASSPHRASE STELLAR_NETWORK STELLAR_ACCOUNT STELLAR_SIGN_WITH_KEY
NET=(--network testnet --rpc-url https://soroban-testnet.stellar.org --network-passphrase 'Test SDF Network ; September 2015')
TARGET=$(stellar keys address "${1:?key alias required}")
MIN=${2:-250000}
BAL=$(curl -fsSL "https://horizon-testnet.stellar.org/accounts/$TARGET" | jq -r '.balances[] | select(.asset_type=="native") | .balance')
ROUNDS=$(python3 -c 'import math,sys; print(max(0, math.ceil((float(sys.argv[1])-float(sys.argv[2]))/39600)))' "$MIN" "$BAL")
[[ "$ROUNDS" -gt 0 ]] || exit 0
[[ "$ROUNDS" -le 30 ]] || { echo 'Funding limit exceeded; inspect fees before continuing.' >&2; exit 1; }
echo "Testnet funding $1: $BAL → at least $MIN XLM ($ROUNDS rounds)"
worker() {
  local who="royalty-rail-faucet-$1" addr round balance
  stellar keys address "$who" >/dev/null 2>&1 || stellar keys generate "$who" "${NET[@]}" >/dev/null
  addr=$(stellar keys address "$who")
  for ((round=1; round<=ROUNDS; round++)); do
    # Friendbot supports topping existing accounts back to its starting balance.
    curl --retry 3 --retry-delay 2 -fsSL "https://friendbot.stellar.org/?addr=$addr" >/dev/null
    stellar tx new payment --source "$who" "${NET[@]}" --destination "$TARGET" --amount 99000000000 >/dev/null
    echo "Faucet $1: $round/$ROUNDS completed"
  done
}
pids=()
for n in 1 2 3 4; do worker "$n" & pids+=("$!"); done
result=0
for pid in "${pids[@]}"; do wait "$pid" || result=1; done
exit "$result"
