#!/usr/bin/env bash
# Prepare the live stage demo. TESTNET ONLY, no real assets or funds.
# Run immediately before presenting: ./demo/stage.sh
# It deliberately does NOT claim the hold; use the writer page after expiry.
set -euo pipefail
cd "$(dirname "$0")/.."
unset STELLAR_RPC_URL STELLAR_NETWORK_PASSPHRASE STELLAR_NETWORK STELLAR_ACCOUNT STELLAR_SIGN_WITH_KEY STELLAR_SEND
NET=(--network testnet --rpc-url https://soroban-testnet.stellar.org --network-passphrase 'Test SDF Network ; September 2015')
D=deployment.json
jq -e '.network == "testnet" and .network_passphrase == "Test SDF Network ; September 2015"' "$D" >/dev/null
RAIL=$(jq -er '.contract_id' "$D")
EURD=$(jq -er '.eurd_token_id' "$D")
WB=$(jq -er '.accounts["writer-b"]' "$D")
UK=$(jq -er '.accounts["uk-society"]' "$D")
WORK=$(jq -er '.work_id' "$D")
[[ "$(stellar keys address uk-society)" == "$UK" ]] || { echo 'Wrong society key for this deployment.' >&2; exit 1; }
rail() { stellar contract invoke --id "$RAIL" "${NET[@]}" "$@"; }
update() { local tmp; tmp=$(mktemp); jq "$@" "$D" > "$tmp"; mv "$tmp" "$D"; }
# An earlier unexpired hold would capture the new statement instead. Refuse it.
COUNT=$(rail --source admin --send=no -- hold_count --payee "$WB")
NOW=$(date -u +%s)
for ((start=0; start<COUNT; start+=20)); do
  OPEN=$(rail --source admin --send=no -- holds_for --payee "$WB" --start "$start" --limit 20 | jq --argjson now "$NOW" '[.[] | select(.open and .expires_at > $now)] | length')
  [[ "$OPEN" == 0 ]] || { echo 'Writer B already has an unexpired hold. Wait for expiry before staging again.' >&2; exit 1; }
done
# Do slow funding BEFORE starting the 120-second stage timer.
./demo/fund-testnet.sh uk-society 50000
SID="UK-STAGE-$(date -u +%Y%m%dT%H%M%S)-$(od -An -N3 -tx1 /dev/urandom | tr -d ' \n')"
HOLD=$(rail --source uk-society -- place_hold --society "$UK" --payee "$WB" \
  --work_id "$(jq -cn --arg w "$WORK" '$w')" --reason MISSING_DATA \
  --note 'Member details need confirmation (demo). Your share stays in escrow until this hold expires.' \
  --duration_secs 120 | jq -r '.')
# Persist the hold immediately, even if the following settlement fails.
update --arg h "$HOLD" '.hold_ids += [$h] | .stage_hold_id=$h'
LINES=$(jq -c --arg w "$WORK" '.lines | map(.work_id=$w)' demo/statement-2027Q4.json)
RESULT=$(rail --source uk-society -- settle --society "$UK" --token "$EURD" --statement_id "$SID" --lines "$LINES")
HOLD_JSON=$(rail --source admin --send=no -- get_hold --hold_id "$HOLD")
# Verify the staged payment actually went to this hold, not directly to the payee.
RECEIPTS=$(rail --source admin --send=no -- statement_receipts --statement_id "$SID")
jq -e --arg p "$WB" --arg h "$HOLD" '[.[] | select(.payee==$p)] | length > 0 and all(.[]; (.status.Held // .status.held // empty | tostring) == $h)' <<< "$RECEIPTS" >/dev/null
update --arg sid "$SID" --arg h "$HOLD" --argjson hold "$HOLD_JSON" --argjson result "$RESULT" \
  '.statement_ids += [$sid] | .stage_statement_id=$sid | .stage={statement_id:$sid,hold_id:$h,expires_at:$hold.expires_at,placed_at:$hold.placed_at,total_held:$result.total_held}'
echo "Stage ready on TESTNET: statement $SID; hold $HOLD"
echo "Writer B: $WB"
echo "Escrow: $(jq -r '.total_held' <<< "$RESULT") base units (350 EURD for the supplied template)"
echo "Expiry: $(jq -r '.expires_at' <<< "$HOLD_JSON"); open the writer page and choose Writer B."
echo 'The page discovers this statement from payee_settled events; deployment.json fallback is also updated.'
