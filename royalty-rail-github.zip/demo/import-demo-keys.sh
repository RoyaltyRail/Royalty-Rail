#!/usr/bin/env bash
# Import ONLY the generated demo identities packaged privately with this repo.
# Never use these keys on mainnet or with real funds. Does not submit transactions.
set -euo pipefail
cd "$(dirname "$0")/.."
KEYS=demo/demo-keys.json
jq -e '.network == "testnet"' "$KEYS" >/dev/null
for who in admin uk-society writer-a writer-b publisher; do
  EXPECTED=$(jq -er --arg who "$who" '.accounts[$who]' deployment.json)
  if ACTUAL=$(stellar keys address "$who" 2>/dev/null); then
    [[ "$ACTUAL" == "$EXPECTED" ]] || { echo "Existing '$who' identity differs. Use a separate Stellar config directory; do not overwrite your own key." >&2; exit 1; }
    echo "$who already imported"
  else
    jq -er --arg who "$who" '.keys[$who]' "$KEYS" | stellar keys add "$who" --secret-key
    [[ "$(stellar keys address "$who")" == "$EXPECTED" ]] || { echo "Address mismatch for $who" >&2; exit 1; }
  fi
done
echo 'Demo testnet keys imported. Keep demo/demo-keys.json private.'
