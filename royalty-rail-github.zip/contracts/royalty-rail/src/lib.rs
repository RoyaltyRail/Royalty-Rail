#![no_std]
//! Royalty Rail — royalty statements where every line carries its own payment receipt.
//!
//! A collecting society settles a statement (a usage report) in a stablecoin.
//! The contract splits each line across the registered rights holders, pays them
//! directly, and stores a receipt per (line, payee) whose hash anyone can verify.
//!
//! Three rules a writer can rely on:
//! 1. Splits only take effect once every rights holder has accepted them, and they
//!    can't be changed without every old and new rights holder accepting the change.
//! 2. Money can't be withheld silently: a hold needs a reason code, a note and an
//!    expiry, and it's published as an event addressed to the writer.
//! 3. Holds can't become indefinite: once a hold expires, anyone (usually the writer)
//!    can release the escrowed money to the writer without the society's consent.
//!
//! And one rule for everyone else on the statement: one writer's problem can't block
//! anyone else's pay. If a payout can't be delivered (e.g. the writer's account has
//! no trustline yet), it's credited to them in the rail and they claim it later.

use soroban_sdk::{
    contract, contracterror, contractevent, contractimpl, contractmeta, contracttype,
    panic_with_error, symbol_short, token, xdr::ToXdr, Address, BytesN, ContractExecutable, Env, Map, String,
    Symbol, Vec,
};

contractmeta!(key = "Description", val = "Royalty Rail: royalty statements with a payment receipt on every line");

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/// Bumped whenever the storage layout or behaviour changes (see `upgrade`).
pub const VERSION: u32 = 2;

const BPS_TOTAL: u32 = 10_000;
/// Longest a single hold (or a single renewal) may run: 90 days.
pub const MAX_HOLD_SECS: u64 = 90 * 24 * 60 * 60;
/// Most lines accepted in one settlement call. Larger usage reports are settled as
/// several statements (e.g. "-part1", "-part2"); this keeps each call well inside
/// network limits on ledger-entry size and event size.
pub const MAX_LINES: u32 = 25;
/// Most receipts (lines x rights holders) in one statement, for the same reason.
pub const MAX_RECEIPTS: u32 = 75;
/// Most rights holders on one work.
pub const MAX_SHARES: u32 = 10;
/// Most holds that can be in force on one payee at a time.
pub const MAX_OPEN_HOLDS: u32 = 5;
/// Page size cap for `holds_for`.
pub const MAX_PAGE: u32 = 20;

const DAY_LEDGERS: u32 = 17_280; // ~5s ledgers
// Extend only when an entry gets close to archival, not on every call.
// The instance (admin, hold counter) and contract code share one TTL; keep them as
// long-lived as the records, so a quiet month can't archive the whole contract.
const INSTANCE_TARGET: u32 = 120 * DAY_LEDGERS;
const INSTANCE_THRESHOLD: u32 = 30 * DAY_LEDGERS;
const RECORD_TARGET: u32 = 120 * DAY_LEDGERS;
const RECORD_THRESHOLD: u32 = 30 * DAY_LEDGERS;

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

#[contracterror]
#[derive(Copy, Clone, Debug, Eq, PartialEq, PartialOrd, Ord)]
#[repr(u32)]
pub enum Error {
    NotSociety = 1,
    SocietyExists = 2,
    WorkExists = 3,
    WorkNotFound = 4,
    BadSplits = 5,
    DuplicatePayee = 6,
    StatementExists = 7,
    EmptyStatement = 8,
    TooManyLines = 9,
    BadAmount = 10,
    BadReason = 11,
    BadDuration = 12,
    HoldNotFound = 13,
    HoldClosed = 14,
    HoldNotExpired = 16,
    StatementNotFound = 18,
    ReceiptNotFound = 19,
    WorkNotActive = 20,
    NoProposal = 21,
    NotAParty = 22,
    TokenNotAllowed = 23,
    TokenExists = 24,
    TooManyShares = 25,
    TooManyHolds = 26,
    NothingToClaim = 27,
}

/// One rights holder's share of a work.
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Share {
    pub payee: Address,
    /// Basis points; all shares of a work sum to 10_000.
    pub bps: u32,
    /// e.g. WRITER, PUBLISHER, ADMIN
    pub role: Symbol,
}

#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Work {
    /// ISWC, e.g. "T-123.456.789-0"
    pub work_id: String,
    pub title: String,
    pub shares: Vec<Share>,
    /// 0 until every rights holder accepts the first splits; then 1, 2, 3...
    /// for each accepted change. Statements can only settle against version >= 1.
    pub version: u32,
}

/// One line of a usage report.
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Line {
    pub work_id: String,
    /// ISO country code, e.g. PT
    pub territory: Symbol,
    /// e.g. 2027Q3
    pub period: Symbol,
    /// e.g. LIVE, RADIO, STREAM, TV
    pub source: Symbol,
    /// Gross amount for this line, in token base units (7 decimals for SAC tokens).
    pub gross: i128,
}

#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ReceiptStatus {
    /// Transferred to the payee's account in the settlement call.
    Paid,
    /// Escrowed under this hold id.
    Held(u64),
    /// The transfer couldn't be delivered (e.g. no trustline); the amount is
    /// credited to the payee in the rail. Collect with `claim_credit`.
    Credited,
}

#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Receipt {
    pub statement_id: String,
    pub line_index: u32,
    pub work_id: String,
    pub work_version: u32,
    pub payee: Address,
    pub role: Symbol,
    pub amount: i128,
    pub territory: Symbol,
    pub period: Symbol,
    pub source: Symbol,
    pub society: Address,
    pub token: Address,
    pub status: ReceiptStatus,
    pub settled_at: u64,
    /// sha256 over the receipt's payment facts (see `receipt_hash`).
    pub hash: BytesN<32>,
}

#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Statement {
    pub statement_id: String,
    pub society: Address,
    pub token: Address,
    pub line_count: u32,
    pub total_gross: i128,
    /// Delivered to payees' accounts.
    pub total_paid: i128,
    /// Credited in the rail because delivery failed.
    pub total_credited: i128,
    /// Escrowed under holds.
    pub total_held: i128,
    pub settled_at: u64,
}

#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Hold {
    pub id: u64,
    /// Only statements from this society are caught by the hold.
    pub society: Address,
    pub payee: Address,
    /// None = applies to every work for this payee.
    pub work_id: Option<String>,
    /// One of: DISPUTE, MISSING_DATA, LEGAL_ORDER, TAX_DOCS, IDENTITY
    pub reason: Symbol,
    pub note: String,
    pub placed_at: u64,
    pub expires_at: u64,
    /// token -> amount escrowed under this hold
    pub escrow: Map<Address, i128>,
    pub open: bool,
}

/// Splits waiting for every party's acceptance.
#[contracttype]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Proposal {
    pub work_id: String,
    pub shares: Vec<Share>,
    /// Everyone who must accept: all current payees plus all proposed payees.
    pub required: Vec<Address>,
    pub accepted: Vec<Address>,
    pub proposed_by: Address,
    pub proposed_at: u64,
}

/// One payee's share of one line, worked out before any money moves.
#[contracttype]
#[derive(Clone)]
struct Alloc {
    idx: u32,
    line: Line,
    work_version: u32,
    share: Share,
    amount: i128,
    hold_id: Option<u64>,
}

#[contracttype]
#[derive(Clone)]
enum DataKey {
    // instance
    Admin,
    NextHoldId,
    // persistent
    Token(Address),
    Society(Address),
    Work(String),
    Proposal(String),
    Statement(String),
    StatementReceipts(String),
    Hold(u64),
    /// Holds that may still catch payments for this payee (<= MAX_OPEN_HOLDS).
    OpenHolds(Address),
    /// Full hold history, paginated: count, then id at each position.
    HoldCount(Address),
    HoldAt(Address, u32),
    /// Undeliverable payouts waiting for the payee: (payee, token) -> amount.
    Credit(Address, Address),
}

// ---------------------------------------------------------------------------
// Events — the writer-facing feed. Payee is a topic wherever it appears, so a
// wallet can subscribe to just its own.
// ---------------------------------------------------------------------------

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SocietyAdded {
    #[topic]
    pub society: Address,
    pub name: String,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TokenAdded {
    #[topic]
    pub token: Address,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SplitsProposed {
    #[topic]
    pub work_id: String,
    pub proposed_by: Address,
    pub shares: Vec<Share>,
    pub required: Vec<Address>,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SplitsAccepted {
    #[topic]
    pub work_id: String,
    #[topic]
    pub payee: Address,
    pub remaining: u32,
}

/// Emitted when the last acceptance lands and the new splits take effect.
#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SplitsActive {
    #[topic]
    pub work_id: String,
    pub version: u32,
    pub old_shares: Vec<Share>,
    pub new_shares: Vec<Share>,
}

/// One per payee per statement. Per-line detail lives in the stored receipts,
/// which keeps events within network limits.
#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PayeeSettled {
    #[topic]
    pub payee: Address,
    #[topic]
    pub statement_id: String,
    pub lines: u32,
    pub paid: i128,
    pub credited: i128,
    pub held: i128,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StatementSettled {
    #[topic]
    pub society: Address,
    #[topic]
    pub statement_id: String,
    pub total_gross: i128,
    pub total_paid: i128,
    pub total_credited: i128,
    pub total_held: i128,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CreditClaimed {
    #[topic]
    pub payee: Address,
    pub token: Address,
    pub amount: i128,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HoldPlaced {
    #[topic]
    pub payee: Address,
    pub hold_id: u64,
    pub society: Address,
    pub work_id: Option<String>,
    pub reason: Symbol,
    pub note: String,
    pub expires_at: u64,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HoldRenewed {
    #[topic]
    pub payee: Address,
    pub hold_id: u64,
    pub note: String,
    pub expires_at: u64,
}

#[contractevent]
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HoldReleased {
    #[topic]
    pub payee: Address,
    pub hold_id: u64,
    /// token -> amount paid out
    pub paid: Map<Address, i128>,
    /// RELEASED (society released it) or EXPIRED (released after expiry).
    pub how: Symbol,
}

// ---------------------------------------------------------------------------
// Contract
// ---------------------------------------------------------------------------

#[contract]
pub struct RoyaltyRail;

#[contractimpl]
impl RoyaltyRail {
    pub fn __constructor(env: Env, admin: Address) {
        env.storage().instance().set(&DataKey::Admin, &admin);
        env.storage().instance().set(&DataKey::NextHoldId, &1u64);
        extend_instance(&env);
    }

    pub fn version(_env: Env) -> u32 {
        VERSION
    }

    /// Admin-only upgrade, so the team can ship fixes without redeploying and
    /// re-registering works. In production this would sit behind a timelock or
    /// governance, or be removed to make the contract immutable.
    pub fn upgrade(env: Env, new_wasm_hash: BytesN<32>) {
        Self::admin(&env).require_auth();
        env.deployer().update_current_contract(ContractExecutable::Wasm(new_wasm_hash));
    }

    // ----- Admin: societies and settlement tokens ---------------------------

    /// Admin onboards a collecting society that may settle statements.
    pub fn add_society(env: Env, society: Address, name: String) {
        Self::admin(&env).require_auth();
        let key = DataKey::Society(society.clone());
        if env.storage().persistent().has(&key) {
            panic_with_error!(&env, Error::SocietyExists);
        }
        env.storage().persistent().set(&key, &name);
        bump(&env, &key);
        extend_instance(&env);
        SocietyAdded { society, name }.publish(&env);
    }

    pub fn is_society(env: Env, society: Address) -> bool {
        env.storage().persistent().has(&DataKey::Society(society))
    }

    /// Admin allowlists a token statements may settle in (e.g. EURC, USDC).
    pub fn add_token(env: Env, token: Address) {
        Self::admin(&env).require_auth();
        let key = DataKey::Token(token.clone());
        if env.storage().persistent().has(&key) {
            panic_with_error!(&env, Error::TokenExists);
        }
        env.storage().persistent().set(&key, &true);
        bump(&env, &key);
        extend_instance(&env);
        TokenAdded { token }.publish(&env);
    }

    pub fn is_token(env: Env, token: Address) -> bool {
        env.storage().persistent().has(&DataKey::Token(token))
    }

    // ----- Works & splits ----------------------------------------------------

    /// Register a work and propose its first splits. The work becomes payable
    /// once every payee has called `accept_splits`. If the registrant is a payee,
    /// their acceptance is recorded straight away.
    pub fn register_work(env: Env, registrant: Address, work_id: String, title: String, shares: Vec<Share>) {
        registrant.require_auth();
        let key = DataKey::Work(work_id.clone());
        if env.storage().persistent().has(&key) {
            panic_with_error!(&env, Error::WorkExists);
        }
        validate_shares(&env, &shares);
        let work = Work { work_id: work_id.clone(), title, shares: Vec::new(&env), version: 0 };
        env.storage().persistent().set(&key, &work);
        bump(&env, &key);
        open_proposal(&env, &work, registrant, shares);
        extend_instance(&env);
    }

    /// Propose new splits for an active work. Only a current rights holder can
    /// propose. Takes effect once every current AND every proposed payee accepts,
    /// so nobody's share can be cut or removed without their signature. Until
    /// then, statements keep settling against the current splits.
    pub fn propose_splits(env: Env, proposer: Address, work_id: String, new_shares: Vec<Share>) {
        proposer.require_auth();
        let work = Self::get_work(env.clone(), work_id);
        if work.version == 0 {
            panic_with_error!(&env, Error::WorkNotActive);
        }
        if !work.shares.iter().any(|s| s.payee == proposer) {
            panic_with_error!(&env, Error::NotAParty);
        }
        validate_shares(&env, &new_shares);
        open_proposal(&env, &work, proposer, new_shares);
        extend_instance(&env);
    }

    /// A rights holder signs the pending splits. The last signature activates them.
    pub fn accept_splits(env: Env, payee: Address, work_id: String) {
        payee.require_auth();
        accept(&env, &work_id, &payee);
        extend_instance(&env);
    }

    pub fn get_proposal(env: Env, work_id: String) -> Option<Proposal> {
        env.storage().persistent().get(&DataKey::Proposal(work_id))
    }

    pub fn get_work(env: Env, work_id: String) -> Work {
        env.storage()
            .persistent()
            .get(&DataKey::Work(work_id))
            .unwrap_or_else(|| panic_with_error!(&env, Error::WorkNotFound))
    }

    // ----- Settlement -----------------------------------------------------------

    /// A society settles a statement in an allowlisted token. The society signs
    /// one transfer of the statement total into the rail; each line is then split
    /// across the work's rights holders and paid out in the same call, one
    /// transfer per payee. Shares under one of this society's active holds are
    /// escrowed instead. If a payout can't be delivered, it's credited to the
    /// payee in the rail rather than failing the statement for everyone.
    /// Every (line, payee) gets a receipt with a verifiable hash.
    pub fn settle(env: Env, society: Address, token: Address, statement_id: String, lines: Vec<Line>) -> Statement {
        // --- checks -----------------------------------------------------------
        society.require_auth();
        let soc_key = DataKey::Society(society.clone());
        if !env.storage().persistent().has(&soc_key) {
            panic_with_error!(&env, Error::NotSociety);
        }
        let tok_key = DataKey::Token(token.clone());
        if !env.storage().persistent().has(&tok_key) {
            panic_with_error!(&env, Error::TokenNotAllowed);
        }
        let stmt_key = DataKey::Statement(statement_id.clone());
        if env.storage().persistent().has(&stmt_key) {
            // Statement ids are unique: no double payment, no silent re-issue.
            panic_with_error!(&env, Error::StatementExists);
        }
        if lines.is_empty() {
            panic_with_error!(&env, Error::EmptyStatement);
        }
        if lines.len() > MAX_LINES {
            panic_with_error!(&env, Error::TooManyLines);
        }
        let mut total_gross: i128 = 0;
        for line in lines.iter() {
            if line.gross <= 0 {
                panic_with_error!(&env, Error::BadAmount);
            }
            total_gross += line.gross; // overflow-checks = true in release
        }
        // Keep entries we rely on alive (threshold-based, so usually a no-op).
        bump(&env, &soc_key);
        bump(&env, &tok_key);

        let tk = token::Client::new(&env, &token);
        let me = env.current_contract_address();
        let now = env.ledger().timestamp();

        // --- pass 1: work out every allocation; no money moves yet -------------
        let mut allocs: Vec<Alloc> = Vec::new(&env);
        // payee -> this society's holds on them that are in force now (loaded once)
        let mut hold_cache: Map<Address, Vec<Hold>> = Map::new(&env);
        // hold id -> amount to escrow under it
        let mut to_escrow: Map<u64, i128> = Map::new(&env);

        for (i, line) in lines.iter().enumerate() {
            let wk = DataKey::Work(line.work_id.clone());
            let work: Work = env
                .storage()
                .persistent()
                .get(&wk)
                .unwrap_or_else(|| panic_with_error!(&env, Error::WorkNotFound));
            if work.version == 0 {
                panic_with_error!(&env, Error::WorkNotActive);
            }
            bump(&env, &wk);

            // Split with integer maths; any rounding remainder goes to the first share.
            let mut amounts: Vec<i128> = Vec::new(&env);
            let mut allocated: i128 = 0;
            for s in work.shares.iter() {
                let a = line.gross * (s.bps as i128) / (BPS_TOTAL as i128);
                allocated += a;
                amounts.push_back(a);
            }
            let remainder = line.gross - allocated;
            if remainder > 0 {
                amounts.set(0, amounts.get_unchecked(0) + remainder);
            }

            for (j, s) in work.shares.iter().enumerate() {
                let amount = amounts.get_unchecked(j as u32);
                if amount == 0 {
                    continue;
                }
                if !hold_cache.contains_key(s.payee.clone()) {
                    hold_cache.set(s.payee.clone(), holds_in_force(&env, &s.payee, &society, now));
                }
                let holds = hold_cache.get_unchecked(s.payee.clone());
                let hold_id = holds
                    .iter()
                    .find(|h| h.work_id.is_none() || h.work_id == Some(line.work_id.clone()))
                    .map(|h| h.id);
                if let Some(id) = hold_id {
                    to_escrow.set(id, to_escrow.get(id).unwrap_or(0) + amount);
                }
                allocs.push_back(Alloc {
                    idx: i as u32,
                    line: line.clone(),
                    work_version: work.version,
                    share: s.clone(),
                    amount,
                    hold_id,
                });
                if allocs.len() > MAX_RECEIPTS {
                    panic_with_error!(&env, Error::TooManyLines);
                }
            }
        }

        // --- move money ----------------------------------------------------------
        tk.transfer(&society, &me, &total_gross);

        // payee -> (to pay, held, lines)
        let mut tallies: Map<Address, (i128, i128, u32)> = Map::new(&env);
        for a in allocs.iter() {
            let (pay, held, n) = tallies.get(a.share.payee.clone()).unwrap_or((0, 0, 0));
            let t = if a.hold_id.is_some() { (pay, held + a.amount, n + 1) } else { (pay + a.amount, held, n + 1) };
            tallies.set(a.share.payee.clone(), t);
        }

        let mut total_paid: i128 = 0;
        let mut total_credited: i128 = 0;
        let mut total_held: i128 = 0;
        let mut undelivered: Map<Address, bool> = Map::new(&env);
        for (payee, (pay, held, n)) in tallies.iter() {
            let mut paid = 0;
            let mut credited = 0;
            if pay > 0 {
                // try_transfer: a failed delivery is caught and rolled back on its
                // own, leaving the money in the rail, instead of reverting the
                // whole statement.
                let delivered = matches!(tk.try_transfer(&me, &payee, &pay), Ok(Ok(())));
                if delivered {
                    paid = pay;
                } else {
                    credited = pay;
                    add_credit(&env, &payee, &token, pay);
                    undelivered.set(payee.clone(), true);
                }
            }
            total_paid += paid;
            total_credited += credited;
            total_held += held;
            PayeeSettled { payee, statement_id: statement_id.clone(), lines: n, paid, credited, held }.publish(&env);
        }

        for (id, amount) in to_escrow.iter() {
            let mut h = load_hold(&env, id);
            h.escrow.set(token.clone(), h.escrow.get(token.clone()).unwrap_or(0) + amount);
            save_hold(&env, &h);
        }

        // --- pass 2: receipts, now that each outcome is known --------------------
        let mut receipts: Vec<Receipt> = Vec::new(&env);
        for a in allocs.iter() {
            let status = match a.hold_id {
                Some(id) => ReceiptStatus::Held(id),
                None if undelivered.contains_key(a.share.payee.clone()) => ReceiptStatus::Credited,
                None => ReceiptStatus::Paid,
            };
            let hash = receipt_hash(
                &env, &statement_id, a.idx, &a.line, a.work_version, &a.share.payee, a.amount, &society, &token,
                &status,
            );
            receipts.push_back(Receipt {
                statement_id: statement_id.clone(),
                line_index: a.idx,
                work_id: a.line.work_id.clone(),
                work_version: a.work_version,
                payee: a.share.payee.clone(),
                role: a.share.role.clone(),
                amount: a.amount,
                territory: a.line.territory.clone(),
                period: a.line.period.clone(),
                source: a.line.source.clone(),
                society: society.clone(),
                token: token.clone(),
                status,
                settled_at: now,
                hash,
            });
        }

        let statement = Statement {
            statement_id: statement_id.clone(),
            society: society.clone(),
            token,
            line_count: lines.len(),
            total_gross,
            total_paid,
            total_credited,
            total_held,
            settled_at: now,
        };
        env.storage().persistent().set(&stmt_key, &statement);
        bump(&env, &stmt_key);
        // All of a statement's receipts live in one ledger entry, so a settlement
        // writes a handful of entries however many lines it carries.
        let rk = DataKey::StatementReceipts(statement_id.clone());
        env.storage().persistent().set(&rk, &receipts);
        bump(&env, &rk);
        extend_instance(&env);

        StatementSettled { society, statement_id, total_gross, total_paid, total_credited, total_held }.publish(&env);
        statement
    }

    /// Deliver a payee's credited (previously undeliverable) payouts. Anyone can
    /// call it — the money can only go to the payee — so the writer, their
    /// manager or a wallet can trigger it once the trustline is fixed.
    pub fn claim_credit(env: Env, payee: Address, token: Address) -> i128 {
        let key = DataKey::Credit(payee.clone(), token.clone());
        let amount: i128 = env.storage().persistent().get(&key).unwrap_or(0);
        if amount <= 0 {
            panic_with_error!(&env, Error::NothingToClaim);
        }
        env.storage().persistent().remove(&key);
        token::Client::new(&env, &token).transfer(&env.current_contract_address(), &payee, &amount);
        extend_instance(&env);
        CreditClaimed { payee, token, amount }.publish(&env);
        amount
    }

    pub fn get_credit(env: Env, payee: Address, token: Address) -> i128 {
        env.storage().persistent().get(&DataKey::Credit(payee, token)).unwrap_or(0)
    }

    pub fn get_statement(env: Env, statement_id: String) -> Statement {
        env.storage()
            .persistent()
            .get(&DataKey::Statement(statement_id))
            .unwrap_or_else(|| panic_with_error!(&env, Error::StatementNotFound))
    }

    /// Every receipt on a statement, in line order.
    pub fn statement_receipts(env: Env, statement_id: String) -> Vec<Receipt> {
        env.storage()
            .persistent()
            .get(&DataKey::StatementReceipts(statement_id))
            .unwrap_or_else(|| panic_with_error!(&env, Error::StatementNotFound))
    }

    pub fn get_receipt(env: Env, statement_id: String, line_index: u32, payee: Address) -> Receipt {
        find_receipt(&env, statement_id, line_index, &payee)
            .unwrap_or_else(|| panic_with_error!(&env, Error::ReceiptNotFound))
    }

    /// A writer checks the hash printed on their statement against the chain.
    pub fn verify_receipt(env: Env, statement_id: String, line_index: u32, payee: Address, hash: BytesN<32>) -> bool {
        match find_receipt(&env, statement_id, line_index, &payee) {
            Some(r) => r.hash == hash,
            None => false,
        }
    }

    // ----- Holds ---------------------------------------------------------------------

    /// A society withholds a payee's future shares from ITS statements (for one
    /// work, or all works). It must give a reason code, a note and an expiry of at
    /// most 90 days. At most MAX_OPEN_HOLDS holds can be in force on a payee.
    pub fn place_hold(
        env: Env,
        society: Address,
        payee: Address,
        work_id: Option<String>,
        reason: Symbol,
        note: String,
        duration_secs: u64,
    ) -> u64 {
        society.require_auth();
        if !Self::is_society(env.clone(), society.clone()) {
            panic_with_error!(&env, Error::NotSociety);
        }
        if !valid_reason(&env, &reason) {
            panic_with_error!(&env, Error::BadReason);
        }
        if duration_secs == 0 || duration_secs > MAX_HOLD_SECS {
            panic_with_error!(&env, Error::BadDuration);
        }
        if let Some(w) = &work_id {
            let work = Self::get_work(env.clone(), w.clone());
            if !work.shares.iter().any(|s| s.payee == payee) {
                panic_with_error!(&env, Error::NotAParty);
            }
        }
        let now = env.ledger().timestamp();

        // Drop expired holds from the in-force index (they stay claimable by id
        // and in the history), then enforce the cap.
        let ok = DataKey::OpenHolds(payee.clone());
        let mut open = Vec::new(&env);
        for id in open_hold_ids(&env, &payee).iter() {
            let h = load_hold(&env, id);
            if h.open && now < h.expires_at {
                open.push_back(id);
            }
        }
        if open.len() >= MAX_OPEN_HOLDS {
            panic_with_error!(&env, Error::TooManyHolds);
        }

        let id: u64 = env.storage().instance().get(&DataKey::NextHoldId).unwrap_or(1);
        env.storage().instance().set(&DataKey::NextHoldId, &(id + 1));

        let hold = Hold {
            id,
            society: society.clone(),
            payee: payee.clone(),
            work_id: work_id.clone(),
            reason: reason.clone(),
            note: note.clone(),
            placed_at: now,
            expires_at: now + duration_secs,
            escrow: Map::new(&env),
            open: true,
        };
        save_hold(&env, &hold);

        open.push_back(id);
        env.storage().persistent().set(&ok, &open);
        bump(&env, &ok);

        let ck = DataKey::HoldCount(payee.clone());
        let n: u32 = env.storage().persistent().get(&ck).unwrap_or(0);
        let ak = DataKey::HoldAt(payee.clone(), n);
        env.storage().persistent().set(&ak, &id);
        bump(&env, &ak);
        env.storage().persistent().set(&ck, &(n + 1));
        bump(&env, &ck);
        extend_instance(&env);

        HoldPlaced { payee, hold_id: id, society, work_id, reason, note, expires_at: hold.expires_at }.publish(&env);
        id
    }

    /// Extend an open, unexpired hold by up to 90 days. Published to the writer.
    pub fn renew_hold(env: Env, hold_id: u64, extra_secs: u64, note: String) {
        let mut h = load_hold(&env, hold_id);
        h.society.require_auth();
        if !h.open {
            panic_with_error!(&env, Error::HoldClosed);
        }
        if env.ledger().timestamp() >= h.expires_at {
            // Expired holds belong to the writer now; a society can't revive one.
            panic_with_error!(&env, Error::HoldClosed);
        }
        if extra_secs == 0 || extra_secs > MAX_HOLD_SECS {
            panic_with_error!(&env, Error::BadDuration);
        }
        h.expires_at += extra_secs;
        h.note = note.clone();
        save_hold(&env, &h);
        extend_instance(&env);
        HoldRenewed { payee: h.payee.clone(), hold_id, note, expires_at: h.expires_at }.publish(&env);
    }

    /// The society that placed the hold releases it and pays out the escrow.
    pub fn release_hold(env: Env, hold_id: u64) -> Map<Address, i128> {
        let h = load_hold(&env, hold_id);
        h.society.require_auth();
        close_and_pay(&env, h, symbol_short!("RELEASED"))
    }

    /// After expiry, anyone (usually the writer) can release the escrow to the
    /// payee. No signature from anyone is needed; the money can only go to the
    /// payee named on the hold.
    pub fn claim_expired(env: Env, hold_id: u64) -> Map<Address, i128> {
        let h = load_hold(&env, hold_id);
        if env.ledger().timestamp() < h.expires_at {
            panic_with_error!(&env, Error::HoldNotExpired);
        }
        close_and_pay(&env, h, symbol_short!("EXPIRED"))
    }

    pub fn get_hold(env: Env, hold_id: u64) -> Hold {
        load_hold(&env, hold_id)
    }

    /// A payee's hold history, oldest first, one page at a time (max 20).
    pub fn holds_for(env: Env, payee: Address, start: u32, limit: u32) -> Vec<Hold> {
        let n: u32 = env.storage().persistent().get(&DataKey::HoldCount(payee.clone())).unwrap_or(0);
        let end = n.min(start.saturating_add(limit.min(MAX_PAGE)));
        let mut out = Vec::new(&env);
        let mut i = start;
        while i < end {
            let id: u64 = env.storage().persistent().get(&DataKey::HoldAt(payee.clone(), i)).unwrap();
            out.push_back(load_hold(&env, id));
            i += 1;
        }
        out
    }

    pub fn hold_count(env: Env, payee: Address) -> u32 {
        env.storage().persistent().get(&DataKey::HoldCount(payee)).unwrap_or(0)
    }

    fn admin(env: &Env) -> Address {
        env.storage().instance().get(&DataKey::Admin).unwrap()
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn open_proposal(env: &Env, work: &Work, proposer: Address, shares: Vec<Share>) {
    let mut required: Vec<Address> = Vec::new(env);
    for s in work.shares.iter().chain(shares.iter()) {
        if !required.contains(&s.payee) {
            required.push_back(s.payee.clone());
        }
    }
    let p = Proposal {
        work_id: work.work_id.clone(),
        shares: shares.clone(),
        required: required.clone(),
        accepted: Vec::new(env),
        proposed_by: proposer.clone(),
        proposed_at: env.ledger().timestamp(),
    };
    // A new proposal replaces any pending one (and its acceptances).
    let k = DataKey::Proposal(work.work_id.clone());
    env.storage().persistent().set(&k, &p);
    bump(env, &k);
    SplitsProposed { work_id: work.work_id.clone(), proposed_by: proposer.clone(), shares, required: required.clone() }
        .publish(env);
    if required.contains(&proposer) {
        accept(env, &work.work_id, &proposer);
    }
}

fn accept(env: &Env, work_id: &String, payee: &Address) {
    let pk = DataKey::Proposal(work_id.clone());
    let mut p: Proposal = env
        .storage()
        .persistent()
        .get(&pk)
        .unwrap_or_else(|| panic_with_error!(env, Error::NoProposal));
    if !p.required.contains(payee) {
        panic_with_error!(env, Error::NotAParty);
    }
    if !p.accepted.contains(payee) {
        p.accepted.push_back(payee.clone());
    }
    let remaining = p.required.len() - p.accepted.len();
    SplitsAccepted { work_id: work_id.clone(), payee: payee.clone(), remaining }.publish(env);

    if remaining > 0 {
        env.storage().persistent().set(&pk, &p);
        bump(env, &pk);
        return;
    }

    // Everyone has signed: activate.
    let wk = DataKey::Work(work_id.clone());
    let mut work: Work = env.storage().persistent().get(&wk).unwrap();
    let old_shares = work.shares.clone();
    work.shares = p.shares.clone();
    work.version += 1;
    env.storage().persistent().set(&wk, &work);
    bump(env, &wk);
    env.storage().persistent().remove(&pk);
    SplitsActive { work_id: work_id.clone(), version: work.version, old_shares, new_shares: p.shares }.publish(env);
}

fn find_receipt(env: &Env, statement_id: String, line_index: u32, payee: &Address) -> Option<Receipt> {
    let all: Vec<Receipt> = env.storage().persistent().get(&DataKey::StatementReceipts(statement_id))?;
    all.iter().find(|r| r.line_index == line_index && r.payee == *payee)
}

fn validate_shares(env: &Env, shares: &Vec<Share>) {
    if shares.is_empty() {
        panic_with_error!(env, Error::BadSplits);
    }
    if shares.len() > MAX_SHARES {
        panic_with_error!(env, Error::TooManyShares);
    }
    let mut sum: u32 = 0;
    let mut seen: Vec<Address> = Vec::new(env);
    for s in shares.iter() {
        if s.bps == 0 || s.bps > BPS_TOTAL {
            panic_with_error!(env, Error::BadSplits);
        }
        if seen.contains(&s.payee) {
            panic_with_error!(env, Error::DuplicatePayee);
        }
        seen.push_back(s.payee.clone());
        sum += s.bps;
    }
    if sum != BPS_TOTAL {
        panic_with_error!(env, Error::BadSplits);
    }
}

fn valid_reason(env: &Env, r: &Symbol) -> bool {
    *r == symbol_short!("DISPUTE")
        || *r == Symbol::new(env, "MISSING_DATA")
        || *r == Symbol::new(env, "LEGAL_ORDER")
        || *r == symbol_short!("TAX_DOCS")
        || *r == symbol_short!("IDENTITY")
}

fn open_hold_ids(env: &Env, payee: &Address) -> Vec<u64> {
    let k = DataKey::OpenHolds(payee.clone());
    let ids: Option<Vec<u64>> = env.storage().persistent().get(&k);
    match ids {
        Some(v) => {
            bump(env, &k);
            v
        }
        None => Vec::new(env),
    }
}

/// This society's holds on this payee that are open and unexpired right now.
fn holds_in_force(env: &Env, payee: &Address, society: &Address, now: u64) -> Vec<Hold> {
    let mut out = Vec::new(env);
    for id in open_hold_ids(env, payee).iter() {
        let h = load_hold(env, id);
        if h.open && now < h.expires_at && h.society == *society {
            out.push_back(h);
        }
    }
    out
}

fn add_credit(env: &Env, payee: &Address, token: &Address, amount: i128) {
    let k = DataKey::Credit(payee.clone(), token.clone());
    let cur: i128 = env.storage().persistent().get(&k).unwrap_or(0);
    env.storage().persistent().set(&k, &(cur + amount));
    bump(env, &k);
}

fn load_hold(env: &Env, id: u64) -> Hold {
    let k = DataKey::Hold(id);
    let h: Hold = env
        .storage()
        .persistent()
        .get(&k)
        .unwrap_or_else(|| panic_with_error!(env, Error::HoldNotFound));
    bump(env, &k);
    h
}

fn save_hold(env: &Env, h: &Hold) {
    let k = DataKey::Hold(h.id);
    env.storage().persistent().set(&k, h);
    bump(env, &k);
}

fn close_and_pay(env: &Env, mut h: Hold, how: Symbol) -> Map<Address, i128> {
    if !h.open {
        panic_with_error!(env, Error::HoldClosed);
    }
    let me = env.current_contract_address();
    for (t, amount) in h.escrow.iter() {
        if amount > 0 {
            // A plain transfer: if delivery fails, the call reverts and the hold
            // stays open, so the writer can fix their trustline and try again.
            token::Client::new(env, &t).transfer(&me, &h.payee, &amount);
        }
    }
    let paid = h.escrow.clone();
    h.open = false;
    h.escrow = Map::new(env);
    save_hold(env, &h);

    // Remove from the in-force index.
    let k = DataKey::OpenHolds(h.payee.clone());
    let mut ids = open_hold_ids(env, &h.payee);
    if let Some(i) = ids.first_index_of(h.id) {
        ids.remove(i);
        env.storage().persistent().set(&k, &ids);
    }
    extend_instance(env);

    HoldReleased { payee: h.payee.clone(), hold_id: h.id, paid: paid.clone(), how }.publish(env);
    paid
}

/// sha256 over the XDR of the receipt's payment facts. Anyone holding the
/// statement can recompute it; `verify_receipt` checks it against the chain.
#[allow(clippy::too_many_arguments)]
fn receipt_hash(
    env: &Env,
    statement_id: &String,
    idx: u32,
    line: &Line,
    work_version: u32,
    payee: &Address,
    amount: i128,
    society: &Address,
    token: &Address,
    status: &ReceiptStatus,
) -> BytesN<32> {
    let facts = (
        statement_id.clone(),
        idx,
        line.clone(),
        work_version,
        payee.clone(),
        amount,
        society.clone(),
        token.clone(),
        status.clone(),
    );
    env.crypto().sha256(&facts.to_xdr(env)).to_bytes()
}

/// Extend a persistent entry only once it's within 30 days of archival.
fn bump(env: &Env, key: &DataKey) {
    env.storage().persistent().extend_ttl(key, RECORD_THRESHOLD, RECORD_TARGET);
}

fn extend_instance(env: &Env) {
    env.storage().instance().extend_ttl(INSTANCE_THRESHOLD, INSTANCE_TARGET);
}

#[cfg(test)]
mod test;
