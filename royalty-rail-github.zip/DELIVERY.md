# Royalty Rail delivery — 25 October 2026

Public writer page: https://royaltyrail-jcebongp.manus.space

All transactions used Stellar testnet and generated demo accounts funded only by Friendbot. No mainnet or real funds were used. The original contract logic and tests are byte-for-byte unchanged.

## 1. Setup

Installed Rust stable 1.99.1, cargo 1.99.1, the wasm32v1-none target, Stellar CLI 28.1.0, and verified jq 1.7. README.md was read before other project files. Versions are recorded in validation/setup.txt.

## 2. Tests

Ran cargo test from the repository root: **31 passed, 0 failed**, with test execution finishing in 0.81 seconds after the first dependency build. Original lib.rs and test.rs fingerprints still match; validation/original-contract-sha256.txt records them. Cargo.lock pins the resolved dependency versions. No contract logic or test changes were made.

## 3. Build

stellar contract build succeeded. target/wasm32v1-none/release/royalty_rail.wasm is **34,058 bytes**, below both 64,000 and 65,536 bytes. Optimized WASM SHA-256: fb45eb6b4f9ab851d839d9578ba4f2a23831da23fbc96eeb05508dbbf45577bc. The compiled WASM is included in this archive.

## 4. Testnet demo

The complete demo succeeded. Q3 paid all recipients. Q4 held writer-b's 350 EURD share, then writer-b claimed that escrow after expiry without society consent. Contract ID, EURD token ID, all five account addresses, and statement/hold IDs are saved in deployment.json.

The script-only CLI fix is JSON-quoting the optional work_id argument to place_hold. Additional script improvements pin the testnet RPC and passphrase, stop masking transaction errors, save milestones for resuming, and wait for actual ledger time rather than sleep 110. Testnet storage rent was unusually high: WASM upload exceeded the initial Friendbot grant and contract creation required about 177,620 test XLM. demo/fund-testnet.sh pools only free Friendbot XLM to cover those fees, without changing contract TTL settings or logic.

Contract: CDLROFPLMWIR4K2OCG2YV75ESGKO2UN4MR3FCGI33I7P4CA3IYI4NAUG

EURD: CBOEK7O5XG35JY2EVZWMOZPLYJWLC3UTXUJAR73N4KFPJPVU6VOXKRAU

## 5. Stage script

Created and successfully ran demo/stage.sh. It checks for an existing unexpired hold, performs funding before starting the timer, places a fresh **120-second MISSING_DATA** hold on writer-b, settles a unique statement, verifies its receipts reference that hold, and saves the hold, statement, and expiry. It does not claim the escrow.

The latest staged statement is UK-STAGE-20261025T174401-51bded, under hold 3. It contains 350 EURD of writer-b escrow left unclaimed at handoff. This hold will already be expired when you review the delivery. Run the script again immediately before presenting to demonstrate a fresh countdown.

## 6. Writer page

The single-page, responsive app in web/ uses @stellar/stellar-sdk 17.4.0 against the pinned testnet RPC. Writer A and Writer B presets come from deployment.json. Statement discovery uses the payee topic of the SDK-emitted payee_settled event, with deployment-ID fallback. RPC returns bounded ledger scans even when no events match; pagination now follows the scan cursor through the retained range instead of incorrectly stopping on an empty page.

Each line shows territory, source, period, amount, and Paid / Held / Credited. Held lines expose their reason, note, and live expiry countdown. Expand Payment receipt for Verify receipt and the one-character tamper toggle. The exact displayed hash is sent to verify_receipt. The holds panel unlocks release once a testnet ledger confirms expiry, using Freighter on testnet or the generated demo writer-b key.

Live checks passed: indexed discovery with no fallback IDs, valid hash true, tampered hash false, a fresh two-minute hold, and rejection of an early claim. A real SDK claim of expired hold 2 confirmed SUCCESS, closed its escrow, and increased writer-b's EURD balance by exactly 350 EURD. Transaction: 93de2abd98552559d2d195bf444c852081f124c6736d17eeaf89350fc6ced58e.

TypeScript and production builds passed. A read-only implementation review was completed and its confirmed issues fixed: unconfirmed pending transactions cannot be reported as paid, and the tampered hash display now matches the submitted hash. Final integration found 9 receipt lines per demo writer, with event discovery and no warnings. Freighter signing is implemented but was not exercised with a user's browser wallet; demo-key signing was exercised successfully.

Receipts remain immutable settlement records. A formerly Held receipt shows current Paid state after release, with a note explaining that the original receipt still records Held and still verifies. Credited records describe the original delivery failure.

## 7. Public deployment and archive

The public deployment completed successfully at the URL above. Saved website version: 908f27134566b6c7cfe759bfc4cdcfb3f63d0528. Public HTML, deployment.json, and the route manifest were checked over HTTPS. Published assets were scanned against the generated demo secrets: no private key is present.

The updated archive contains the unchanged contract, Cargo.lock, compiled WASM, demo scripts, deployment.json, web source and dependency lockfile, fonts and their licenses, and validation logs. Rust build caches, node_modules, and Git metadata are excluded.

## Presenting from a new computer

Run ./demo/import-demo-keys.sh to import this deployment's generated accounts. It refuses to overwrite a different existing identity. Run ./demo/stage.sh just before presenting, then choose Writer B on the public page and Refresh. New stage statements appear from events without republishing.

For release, open Release signing and paste only the writer-b value from demo/demo-keys.json, or use Freighter configured for testnet. The key input is memory-only. The private archive includes the newly generated demo keys so you can operate the existing deployment, but **do not publish demo/demo-keys.json, reuse its keys on mainnet, or put real funds into these accounts**. The file is ignored by Git and was never copied to the public website.
